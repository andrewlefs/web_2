<?php
    define('SITEOFF','yes1');
    define('Version','2.1');
    define('TPL','/azmart2.1');
    define('TPL_LINK',WEB_DOMAIN.TPL);
?>