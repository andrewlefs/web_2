<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='../index.php'>Login</a> to Web Contents Manager !");
}
$cat 	= array();
$subcat = array();
$faq 	= array();
$intro	= array();
$sol 	= array();
$pro2 	= array();
$new 	= array();
$logo 	= array();
$slider	= array();
$yahoo	= array();
$keyword	= array();
$technew	= array();
$new_tags	= array();
$new_event	= array();
$new_event1	= array();
$currency 	= array();
$ysupport 	= array();
$khachhang	= array();
$seolink 	= array();
$vote_index	= array();
$newscat 	= array();
$ser_sitemap	= array();
$cuscat_sitemap = array();
$downloadcat = array();
$weblist_tags 	= array();
$configuration 	= array();
$manufacturers 	= array();
$config_HG      = array ();
$pro_hot = array();
$dm_nsx1 = array();
$dm_price1 = array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();	
$counter = $sql->get_counter();

$select_query = "SELECT id, keyword, description, intro, siteurl, siteemail, contact, footer, sitename FROM settings";
$sql->query($select_query);
while($rows = $sql->fetch_array()){
    $config_HG["keyword"]	= $rows["keyword"];
    $config_HG[$i]["description"]   = $rows["description"];
    $config_HG[$i]["siteurl"]	= $rows["siteurl"];
    $config_HG[$i]["siteemail"]	= $rows["siteemail"];
    $config_HG["contact"]	= $rows["contact"];
    $config_HG["intro"]         = $rows["intro"];
    $config_HG["footer"]        = $rows["footer"];
    $config_HG["sitename"]	= $rows["sitename"];						
}
//San pham hot
$select_query = "select SanphamID,ten,gia,anh, discount from sanpham where noibat=1  AND discount > 0 order by CreateDate,SanphamID DESC limit 8";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
    $i = $i + 1;
    $pro_hot[$i]["id"]          = $rows["SanphamID"];
    $pro_hot[$i]["discount"] 	= $rows["discount"] >0 ? '<span>'.$rows["discount"].' %</span>' : '';
    $pro_hot[$i]["name"]        = $rows["ten"];
    $pro_hot[$i]["img"]         = $rows["anh"];
    $pro_hot[$i]["price"] 	= $rows["gia"];
    $pro_hot[$i]["catid"] 	= $rows["catid"];
    $pro_hot[$i]["subcatid"]    = $rows["subcatid"];
    $giamgia                    = $rows["discount"] * $rows["gia"] /100 ;
    $pro_hot[$i]["giaban"]      = $rows["gia"] - $giamgia ;
    
    
    
}

//get info of category
$select_query = "SELECT nsxid, anh, tennsx FROM nsx ORDER BY tennsx";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
    $i = $i + 1;
    $manufacturers[$i]["Id"]       = $rows["nsxid"];
    $manufacturers[$i]["Name"]     = $rows["tennsx"];	
    $manufacturers[$i]["img"]      = $rows["anh"];	
}

//get info of category
$select_query = "SELECT catid, anh, catname FROM cat WHERE hienthi =1 ORDER BY thutu, catname";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
    $i = $i + 1;
    $cat[$i]["catid"]       = $rows["catid"];
    $cat[$i]["catname"]     = $rows["catname"];	
    $cat[$i]["img"]         = $rows["anh"];	
}
//get info of category
$select_query = "SELECT subcatid, catid, subcatname FROM subcat ORDER BY subcatid";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
    $i = $i + 1;
    $subcat[$i]["subcatid"] 	= $rows["subcatid"];
    $subcat[$i]["subcatname"] 	= $rows["subcatname"];	
    $subcat[$i]["catid"] 	= $rows["catid"];
}
$select_query = "SELECT id, yahooname, nickname FROM yahoo ORDER BY thutu ASC";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$yahoo[$i]["id"] 		= $rows["id"];
	$yahoo[$i]["yahooname"] 	= $rows["yahooname"];	
	$yahoo[$i]["nickname"] 		= $rows["nickname"];	
}
$select_query = "SELECT tinid, tieude, anhtin, ngaydang FROM tintuc ORDER BY ngaydang DESC,tieude LIMIT 0, $latest_news";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$new[$i]["tinid"] 	= $rows["tinid"];
	$new[$i]["tieude"] 	= $rows["tieude"];
	$new[$i]["ngaydang"] 	= $rows["ngaydang"];
        $new[$i]["anhtin"] 	= $rows["anhtin"];
}







$select_query = "SELECT nsxid,tennsx,anh FROM nsx where publish=1 ORDER BY thutu, tennsx";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$i = $i + 1;
		$dm_nsx1[$i]["nsxid"] 	= $rows["nsxid"];		
		$dm_nsx1[$i]["tennsx"] = $rows["tennsx"];
                $dm_nsx1[$i]["anh"] = $rows["anh"];
	}
        
        $select_query = "SELECT id,name FROM khoanggia order by id,name desc";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$i = $i + 1;
		$dm_price1[$i]["id"] 	= $rows["id"];		
		$dm_price1[$i]["name"] = $rows["name"];
	}









//get info of currency
$select_query = "SELECT name, rate FROM currency";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$currency[$i]["rate"] 	= $rows["rate"];
	$currency[$i]["name"] 	= $rows["name"];	
}

//get seolink
$select_query = "SELECT * FROM linkseo WHERE publish = 1 ORDER BY list_order";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$linkseo[$i]["id"] 		= $rows["id"];
	$linkseo[$i]["keyword"] 	= $rows["keyword"];
	$linkseo[$i]["linkweb"] 	= $rows["linkweb"];
}
$select_query = "SELECT * FROM linkseo ORDER BY list_order";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$linkseo2[$i]["id"] 		= $rows["id"];
	$linkseo2[$i]["keyword"] 	= $rows["keyword"];
	$linkseo2[$i]["linkweb"] 	= $rows["linkweb"];
}

//get intro menu
$select_query = "SELECT * FROM intro WHERE publish = 1 ORDER BY list_order";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$intro[$i]["menu_title"] 	= $rows["menu_title"];
	$intro[$i]["id"]                = $rows["id"];
}



//get logo of right menu
$select_query = "SELECT logo, link, position FROM doitac WHERE publish = 1 ORDER BY position, thutu";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$logo[$i]["logo"] 	= $rows["logo"];
	$logo[$i]["link"]  	= $rows["link"];
	$logo[$i]["position"]  	= $rows["position"];
}
$select_query = "SELECT logo, link, content, position FROM slider WHERE publish = 1 ORDER BY thutu";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$slider[$i]["logo"] 		= $rows["logo"];
	$slider[$i]["content"] 		= $rows["content"];
	$slider[$i]["position"] 	= $rows["position"];
	$slider[$i]["link"]  		= $rows["link"];
}

$select_query = "SELECT id, title FROM newscat ";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$newscat[$i]["id"] 	= $rows["id"];
	$newscat[$i]["title"] 	= $rows["title"];	
}
function get_subcat($catid){
     $sub_cat = array();
    $sql = new db_sql();
    $sql->db_connect();
    $sql->db_select();
    $select = "select subcatid,subcatname from subcat where catid=$catid";
    $sql->query($select);
    $i=0;
    while($row = $sql->fetch_array()){
        $i++;
        $sub_cat[$i]["subcatid"] = $row["subcatid"];
        $sub_cat[$i]["subcatname"] = $row["subcatname"];
    }
    return $sub_cat;
}


$sql->close();


function get_catname($catid){
		global $Ncatname, $cat;
		for($i=1; $i<=count($cat); $i++){
			if($cat[$i]["catid"]==$catid){
				$Ncatname = $cat[$i]["catname"];
				break;
			}				
		}
	return $Ncatname;
	}
        
        function get_subcatname($subcatid){
		global $Ncatname, $subcat;
		for($i=1; $i<=count($subcat); $i++){
			if($subcat[$i]["subcatid"]==$subcatid){
				$Ncatname = $subcat[$i]["subcatname"];
				break;
			}				
		}
	return $Ncatname;
	}
        
        function hinhanh($idsp){
                $hinhanh;
              $sql = new db_sql();
                $sql->db_connect();
                $sql->db_select();
                $select = "select anh from sanpham where SanphamID=$idsp limit 1";
                $sql->query($select);              
                $row = $sql->fetch_array();
                 $hinhanh = $row['anh'];
                return $hinhanh;
        }
        
        
        
         function get_intro_sanpham1($idsp){
            $intro_sp = array();
             $sql_menu   = new db_sql();
            $sql_menu->db_connect();
            $sql_menu->db_select();
            $menu_select_query = "SELECT ten,gia,anh,namsx,km,thongso,mota,noibat,moi,subcatid,catid FROM sanpham where SanphamID='$idsp' limit 1";
            $sql_menu->query($menu_select_query);
  
            while($rows = $sql_menu->fetch_array()){  
                    $intro_sp["ten"] 	= $rows["ten"];		
                    $intro_sp["gia"] = $rows["gia"];
                    $intro_sp["anh"] = $rows["anh"];
                    $intro_sp["namsx"] = $rows["namsx"];
                    $intro_sp["km"] = $rows["km"];
                    $intro_sp["thongso"] = $rows["thongso"];
                    $intro_sp["mota"] = $rows["mota"];
                    $intro_sp["noibat"] = $rows["noibat"];
                    $intro_sp["moi"] = $rows["moi"];
                    $intro_sp["subcatid"] = $rows["subcatid"];
                    $intro_sp["catid"] = $rows["catid"];
            }
            return $intro_sp;
        }

        
?>