﻿<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();		
	$position_page = isset($_GET["position_page"]) && is_numeric($_GET["position_page"])  ? $HTTP_GET_VARS["position_page"]:1;
	$position_page = isset($_POST["position_page"]) ? $_POST["position_page"] : $position_page; 
	$from = $position_page ==1 ? 0 : (($new_per_page*$position_page)- $new_per_page);
	$count_rows = $sql->count_rows("contact");
	$pages_number = ceil($count_rows/$new_per_page);
	
	if(session_is_registered('countadd'))
	{
		$HTTP_SESSION_VARS['countadd']=0;
	}
	$select_query = "SELECT contactid, title, senddate FROM contact ORDER BY senddate DESC LIMIT $from, $new_per_page";
	$sql->query($select_query);
	$n = $sql->num_rows();					
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
	function delContact(id) {
		if (confirm("Are you sure ?" )) {
			window.location.replace("index.php?pages=contact&mode=del&id=" + id);			
		}
	}
	function open_window(id){
			window.open("index.php?pages=contact&mode=detail&id=" +id ,"","width=600,height=350,left=0,top=0,scrollbars=yes");
	}
</script>
<div align="center">
<table width="900" border="0" align="center" cellpadding="2" cellspacing="0">
  <tbody>
    <tr>
      <td width="143" align="center" bgcolor='whitesmoke' class="logout">[ <a href="index.php?pages=logout">Logout</a> ]</td>
      <td align="center" bgcolor='whitesmoke' class="menu_bar_manager">[ <a href="index.php?pages=contact">Khách hàng liên hệ</a>]</td>
    </tr>
  </tbody>
</table>
<table width="900" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
		<td width="100%" valign="top" bgcolor='#ffffff'>
	 <? if($count_rows>0){ ?>
  </form>
	<center>	<div align="center">
	  <?php if(!message=="") echo "<span class='error'>".$message."</span>"; ?>
	 <br>	  
<table width="100%" bgcolor='#ffffff'>
 <tr>
<td class="header_table" bgColor="whitesmoke"><?php pages_browser_admin("index.php?pages=contact&position_page=",$position_page,$pages_number);?></td>
        </tr>
      </table>
	<table width="100%" bgcolor='#ffffff'>
        <tr>
          <td class="header_table">C&oacute; <span class="style1"><?=$count_rows?></span> th&#432; li&ecirc;n h&#7879; hoặc góp &yacute; của khách hàng</td>
        </tr>
      </table>
	  <table borderColor="whitesmoke" cellSpacing="0" cellPadding="2" width="100%" align="center" border="1">
        <tr bgColor="whitesmoke">
          <td width="33" align="middle" class="colum_order" > Order</td>
          <td width="303" class="header_table" > Contact Name </td>
          <td width="138" class="header_table" >Send Date </td>
          <td >&nbsp; </td>
        </tr>
		<?php
        for($i=1; $i<$n+1; $i++){
			$from = $from + 1;		
			$row = $sql->fetch_array();
			$contactid 	= 	$row['contactid'];
			$title 		=	$row['title'];
			$senddate = gmdate("d/m/Y, h:i, a",$row["senddate"] + 7*3600);			
		?>
		<tr>
          <td align="middle" class="colum_order" > <?= $from ?></td>
          <td class="header_table" ><span class="manager_link"><a title="Information detail" style="CURSOR: hand" onClick="open_window(<?=$contactid?>)">
            <?= $title ?>
          </a></span></td>
          <td class="header_table" ><?= $senddate ?></td>
          <td width="50" align="center">
            <table cellSpacing="0" cellPadding="2" width="50" border="0">
              <tr>                
                <td width="46" > <a style="CURSOR: hand" onClick="delContact(<?=$contactid ?>)"> <img height="13" alt="Delete" src="../images/del_button.gif" width="36" border="0"></a></td>
              </tr>
          </table></td>
		</tr>
		<?php 
		} $sql->close();
		?>
      </table>  
<table width="100%">
 <tr>
<td class="header_table" bgColor="whitesmoke"><?php pages_browser_admin("index.php?pages=contact&position_page=",$position_page,$pages_number);?></td>
        </tr>
      </table>	  
	</div>
	<?
	}else echo"<br><div align=center>&nbsp;&nbsp;Chưa có thư liên hệ hoặc góp ý nào trong CSDL !</div>";
	?>
        </td>
</tr>
</table> 
</div></body>
</html>