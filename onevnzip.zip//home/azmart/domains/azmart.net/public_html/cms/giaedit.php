<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}	
	if($HTTP_GET_VARS["mode"] == "edit" && $HTTP_GET_VARS["pages"]=="gia")
	{
		$id_gia = $_GET[id];
		$select_query = "SELECT name, price_from,price_to FROM khoanggia WHERE id = $id_gia";
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
		$sql->query($select_query);
		$row 	= $sql->fetch_array();
		$name = $row["name"];
		$from = $row["price_from"];
                $to = $row["price_to"];
	}
	if($HTTP_POST_VARS["mode"] == "edit" && $HTTP_POST_VARS["pages"]=="gia")
	{
		$id_gia1 = $_POST["id"];
		$name = convert_font($_POST["name"],2);
		$from = $_POST["from"];
                $to = $_POST["to"];
		$update_query = "UPDATE khoanggia SET name='$name', price_from='$from',price_to='$to' WHERE id = $id_gia1";
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
		$sql->query($update_query);
		$sql->close();
		$message = "Cập nhật thông tin thành công !";		
		require_once("gia.php");
		exit();
	}
	
?>
<?php include("lib/header.php")?>
<div id="content">
  <div class="breadcrumb">
            <a href="/">Home</a>
            :: <a href="index.php?pages=gia">Quản lý đơn vị tiền tệ </a>
     </div>
    <?php if($message!="") echo "<div class='warning'>Warning: ".$message."</div>"; if($message1!="") echo "<div class='warning'>Warning: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Sửa đơn vị tiền tệ</h1>
      
      <form action=index.php method=post enctype="multipart/form-data" name="nsxedit" id="nsxedit" onSubmit="return numberValidation(document.getElementById('rate'))">
      <div class="buttons"><input type="submit" value="Cập nhật" name="submit" class="submit1" ><a onclick="location = ''" class="button">Cancel</a></div>
    </div>
    <div class="content">
         <div id="tab-general">
          
            <div id="language1">        
            <table class="form">
              <tr>
                <td><span class="required">*</span> Tên khoảng giá:</td>
                <td><input type="text" name="name" size="100" id="name" value="<?=$name?>" />
                  </td>
              </tr>
                <tr>
                <td><span class="required">*</span>Giá từ:</td>
                <td><input type="text" name="from" size="100" id="from" value="<?=number_format($from)?>" />
                  </td>
              </tr>
               <tr>
                <td><span class="required">*</span>Giá đến:</td>
                <td><input type="text" name="to" size="100" id="to" value="<?=number_format($to)?>" />
                  </td>
              </tr>
            </table>
          </div>
       </div>
        <input name="pages" type="hidden" id="pages" value="gia">
        <input name="mode" type="hidden" id="mode" value="edit">
	<input name="id" type="hidden" id="id" value="<?=$id_gia?>">
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>
