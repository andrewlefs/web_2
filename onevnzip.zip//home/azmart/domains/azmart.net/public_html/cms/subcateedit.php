<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();
           $intro_cat = array();
          
               //get thong tin cat(danh muc cha)
           $select = "select catid,catname from cat where hienthi=1 order by thutu,catname";
           $sql->query($select);
           $i=0;
           while ($rows = $sql->fetch_array()){
               $i=$i+1;
               $intro_cat[$i]["catid"] = $rows["catid"];
               $intro_cat[$i]["catname"] = $rows["catname"];
           }
	if($HTTP_GET_VARS[mode] == "edit")
	{
		$subid = $_GET["id"];
		$select_query = "SELECT subcatname,catid FROM subcat WHERE subcatid = $subid limit 1";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$subcatname = $row["subcatname"];		
                                                      $catid2 = $row["catid"];
		$n = $sql->count_rows("subcat");	
	}
	
	if($HTTP_POST_VARS[mode] == "edit")
	{
                                                     $catid2 = $_POST["catid"];
		$subid = $_POST["id"];
		$subcatname = convert_font($_POST["subcatname"],2);		
		$update_query = "UPDATE  subcat SET subcatname='$subcatname', catid='$catid2'  WHERE subcatid = $subid";
		$sql->query($update_query);
		$sql->close();
		$message = "Cập nhật thành công !";
                header("Location: index.php?pages=subcate");
		exit();
	}	
?>

<?php include("lib/header.php")?>
<div id="content">
<div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=subcate">Quản lý danh mục </a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='success'>Success: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" /> Danh mục sản phẩm</h1>
      <form action=index.php method=post enctype="multipart/form-data" name="subcateedit" id="subcateedit">
      <div class="buttons">
            <input type="submit" value="Update" name="submit" class="submit1" > 
            <a onclick="location = ''" class="button">Cancel</a></div>
    </div>
    <div class="content">
       <div id="tab-general">
       <div id="language1">
            <table class="form">
                      <tr>
                    <td><span class="required">*</span>Chọn danh mục sản phẩm cha</td>
                    <td>
                        <select name="catid" id="catid">
                            <?php
                                for($i=1;$i<=count($intro_cat);$i++){
                                    if($intro_cat[$i]["catid"]==$catid2){?>
                            <option value="<?=$intro_cat[$i]['catid']?>" selected><?php echo $intro_cat[$i]["catname"];?></option>
                                <?}else{?>
                                     <option value="<?=$intro_cat[$i]['catid']?>"><?php echo $intro_cat[$i]["catname"];?></option>
                                <?}
                                }
                            ?>
                        </select>
                    </td>
                </tr>
              <tr>
                <td><span class="required">*</span> Tên danh mục:</td>
                <td><input type="text" name="subcatname" size="100" id="subcatname" value="<?=$subcatname?>" />
                  </td>
              </tr>
        
            </table>
          </div>
       </div>
        <input name="pages" type="hidden" id="pages" value="subcate">
        <input name="mode" type="hidden" id="mode" value="edit">
        <input name="id" type="hidden" id="id" value="<?=$subid?>">       
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>

