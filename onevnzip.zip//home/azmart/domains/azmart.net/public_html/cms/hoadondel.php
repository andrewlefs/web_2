<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	
	if ($HTTP_GET_VARS["mode"]=="del" && $HTTP_GET_VARS["pages"]=="hoadon" )
	{

            $id = $_GET["id"];
            $sql = new db_sql();
            $sql->db_connect();
            $sql->db_select();

		

                    $delete_query = "DELETE FROM hoa_don WHERE id = $id";
                 
                    $sql->query($delete_query);	
            
                    $message= "<li>Xóa thành công !";
                    require_once("hoadon.php");
                    exit();
							
	}
?>
