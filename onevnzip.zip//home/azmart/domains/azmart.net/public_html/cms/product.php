<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$module_name = 'Quản lý sản phẩm';
	if(session_is_registered('countadd')) //get number record input in databases
	{
            $HTTP_SESSION_VARS['countadd']=0;
	}
        $cat_pr = array();
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();
        $select_query = "SELECT catid, catname FROM cat WHERE hienthi=1 ORDER BY thutu, catname";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$i = $i + 1;
		$cat_pr[$i]["id"] 	= $rows["catid"];
		$cat_pr[$i]["name"] 	= $rows["catname"];	
	}
        
	$cat_id	= isset($_GET["cat_id"])   ? $_GET["cat_id"]   : (isset($_POST["cat_id"])  ? $_POST["cat_id"]  : "");	               
        $rows_per_page_of_product = is_numeric($rows_per_page_of_product) && $rows_per_page_of_product>0 ? $rows_per_page_of_product : 1;
        //$rows_per_page_of_product = 4;
        $position_page = isset($HTTP_GET_VARS["position_page"]) && is_numeric($HTTP_GET_VARS["position_page"])  ? $HTTP_GET_VARS["position_page"]:1; 
        $position_page = isset($_POST["position_page"]) ? $_POST["position_page"] : $position_page ;	
        $count_rows = $sql->count_rows("sanpham");	
        $pages_number = ceil($count_rows/$rows_per_page_of_product);
        $position_page = ($position_page > $pages_number) ? 1 : $position_page;
        $from = $position_page ==1 ? 0 : (($rows_per_page_of_product*$position_page)- $rows_per_page_of_product);
        $select_query = "   SELECT SanphamID, model, ten, gia, discount, anh, catid, CreateDate,publish 
                            FROM sanpham ".($cat_id>0?"WHERE catid = $cat_id":"")." 
                            ORDER BY ten LIMIT $from, $rows_per_page_of_product";
        $sql->query($select_query);
        $n = $sql->num_rows();
        
	function get_subcatname($subcatid){
		global $subcatname, $subcat;
		for($i=1; $i<=count($cat); $i++){
			if($subcat[$i]["subcatid"]==$subcatid){
				$subcatname = $subcat[$i]["subcatname"];
				break;
			}				
		}
	return $subcatname;
	}
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
	function delProduct(id,position_page) {
		if (confirm("Bạn có muốn xóa thật không ?" )) {
			window.location.replace("index.php?pages=product&mode=del&act=del&position_page="+position_page+"&id=" + id);			
		}
	}
	function open_window(id){
			window.open("index.php?pages=product&mode=detail&id=" +id ,"","width=700,height=500,left=0,top=0,scrollbars=yes");
	}
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=<?= $pages ?>"><?= $module_name ?></a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>";?>
      <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" /><?= $module_name ?> (<?=$n?>) </h1> 
      <div class="buttons"><a onclick="location = 'index.php?pages=<?= $pages ?>&mode=add'" class="button">Thêm</a></div>
    </div>
    <div class="content"> 
        <tr>
          <td class="header_table"><div align="left">
            <form action="index.php?pages=product" method="post"  enctype="multipart/form-data" name="product"  id="product" style="float:left; margin-right:20px;" >
                <select size="1" name="cat_id" id="cat_id" onchange="document.location='index.php?pages=product&cat_id=' + document.getElementById('cat_id').value ">
                          <option value="0">All</option>
                          <?php
                          for($i=1;$i<=count($cat_pr);$i++)
                                if($cat_pr[$i]["id"] == $cat_id)
                                        echo "<option value='".$cat_pr[$i]["id"]."' selected>".$cat_pr[$i]["name"]."</option>";
                                else
                                        echo "<option value='".$cat_pr[$i]["id"]."'>".$cat_pr[$i]["name"]."</option>";
                          ?>
                  </select>
              <input name="cat_id" type="hidden" id="cat_id" value="<?=$cat_id?>">
            </form>
           </div>
	</td>
        </tr>
        <? if($n>0){ ?>
        <table class="list">
          <thead>
            <tr>
              <td class="tt">#</td>
              <td class="center">Hình ảnh</td>
              <td class="left">Model</td>
              <td class="left">Tên sản phẩm</td>
              <td class="center">Giảm giá</td>
              <td class="left">Giá bán</td>
              <td class="center">Publish</td>
              <td class="right">Công cụ</td>
            </tr>
          </thead>
          <tbody>
              <?php
                for($i=1; $i<$n+1; $i++)  {
                    $from       = $from + 1;
                    $rows       = $sql->fetch_array();
                    $sanphamid 	= $rows['SanphamID'];
                    $model      = $rows['model'];
                    $ten        = $rows['ten'];
                    $gia        = $rows['gia']; //<> "" ? '<p class="km">'.$row["km"].'</p>' : '';
                    $discount   = $rows['discount']  >0 ? $rows['discount'].'%' : ''; 
                    $anh        = $rows["anh"] <> "" ? "<img src='".$dir_imgproducts.$rows["anh"]."'  style='padding: 1px; border: 1px solid #DDDDDD; width:40px; '>" : 'Chua Anh';
                    $ngaydang   = $rows["CreateDate"];
                    $change     = $rows['publish']==0?1:0;
                    $publish    = $rows["publish"];
      
                
            ?>
            <tr>
              <td class="tt"><?= $sanphamid ?></td>
              <td class="center"><?= $anh ?></td>
              <td class="left"><?= $model ?></td>
              <td class="left"><?= $ten ?></td>
              <td class="center"><?= $discount ?></td>
              <td class="left"><?= gia($gia) ?></td>
              <td class="center"><?= ($publish == 1 ? '<a style="CURSOR: hand" href="index.php?pages=product&mode=del&amp;act=upd&s='.$change.'&id='.$sanphamid.'"><img src="images/publish.png" alt="Publish" /></a>' : '<a style="CURSOR: hand" href="index.php?pages=product&mode=del&amp;act=upd&s='.$change.'&id='.$sanphamid.'"><img src="images/unpublish.png" alt="Publish" /></a>') ?></td>
                <td class="right"><a style="CURSOR: hand" href="index.php?pages=product&mode=edit&position_page=<?=$position_page?>&id=<?= $sanphamid ?>"><img src="images/edit_button.gif" alt="Edit" /></a>
                                <a style="CURSOR: hand" onClick="delProduct('<?=$sanphamid?>','<?=$position_page?>')"><img src="images/del_button.gif" alt="Del" /></a>
                </td>
            </tr>
            <?php 
                 } $sql->close();
            ?>

        </tbody>
        </table>
        <?php pages_browser_admin("index.php?pages=product&position_page=",$position_page,$pages_number);?>
        <? }else echo "<br><div align=center>Chưa có sản phẩm  nào trong CSDL !</div>";?>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>