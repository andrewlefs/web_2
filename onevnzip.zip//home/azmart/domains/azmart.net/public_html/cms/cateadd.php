<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	if($HTTP_POST_VARS["mode"] == "add" && isset($HTTP_POST_VARS["mode"])){
		if(!session_register('countadd')){
			session_register('countadd');
			$HTTP_SESSION_VARS['countadd']=0;
		}
		$catname = convert_font($HTTP_POST_VARS["catname"]);
		$hienthi = $HTTP_POST_VARS["hienthi"]==1?$HTTP_POST_VARS["hienthi"]:0;
                $acce   = $HTTP_POST_VARS["acce"]==1?$HTTP_POST_VARS["acce"]:0;
		$anh 	= isset($_FILES["anh"]["name"])    ? $_FILES["anh"]["name"] : '';	
                $thutu  = $HTTP_POST_VARS["thutu"];
		$message1 = $catname == "" ? "Hãy nhập tên danh mục sản phẩm" : "";
                if ( !empty($anh)){
			$filename = "";
                        $start = strpos($anh,".");
			$type  = substr($anh,$start,strlen($anh));
                        $filename = "icon".time().$type;
                                if ( !(copy($_FILES['anh']['tmp_name'], $dir_imglogos.$filename)) ) die("Cannot upload file.");
		}
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();		
		$n = $sql->count_rows("cat") + 1;
		if($message1 ==""){
			$catname = convert_font($HTTP_POST_VARS["catname"],2);
			$insert_query = "INSERT INTO cat(anh, catname, acce, hienthi, thutu) VALUES('$filename', '$catname', $acce, $hienthi, $thutu)";			
			if($sql->query($insert_query)){	
                            unset($catname);
				$HTTP_SESSION_VARS['countadd'] = $HTTP_SESSION_VARS['countadd'] + 1;
				$message = "Th&ocirc;ng tin v&#7873; danh mục sản phẩm th&#7913; ".$HTTP_SESSION_VARS['countadd']." &#273;&atilde; &#273;&#432;&#7907;c th&ecirc;m v&agrave;o CSDL";			
			}		
			$n = $sql->count_rows("cat") + 1;										
			$sql->close();	
		}
	}	
	else{
			$sql = new db_sql();
			$sql->db_connect();
			$sql->db_select();
			$n = $sql->count_rows("cat") + 1;
			$sql->close();
	}
?>
<?php include("lib/header.php")?>
<div id="content">
<div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=cate">Quản lý danh mục </a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='success'>Success: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" /> Danh mục sản phẩm</h1>
      <form action="index.php" method="post" enctype="multipart/form-data" name="add" id="add">
      <div class="buttons"><input type="submit" value="Thêm" name="submit" class="submit1" ><a onclick="location = ''" class="button">Cancel</a></div>
    </div>
    <div class="content">
       <div id="tab-general">
       <div id="language1">
            <table class="form">
              <tr>
                <td><span class="required">*</span> Tên danh mục:</td>
                <td><input type="text" name="catname" size="100" id="catname" value="<?=$catname?>" />
                  </td>
              </tr>
            <tr>
              <td>Hiển thị:</td>
              <td><input name="hienthi" type="checkbox" id="hienthi" value="1" checked></td>
            </tr>
            <tr>
                    <td><span class="required">*</span>Icon</td>
                    <td>
                        <input name="anh" type="file" value="<?=$anh?>" size="32">
                    </td>
                </tr>
            <tr>
              <td>Thứ tự hiển thị:</td>
              <td>  <select name="thutu" size="1" id="thutu">
                       
                                <?php  
                                 for($i=1; $i<=$n; $i++){
                                 ?>
                                        <OPTION value="<?=$i?>"><?=$i?></OPTION>
                                 <?php }
                                 ?>    
                            
                            
                            
                        <OPTION value="<?=$n+1?>" selected><?=$n+1?></OPTION>
                    </select></td>
            </tr>
            </table>
          </div>
       </div>
        <input type="hidden" value="Add" name="submit">
        <input name="pages" type="hidden" id="pages" value="cate">
        <input name="mode" type="hidden" id="mode" value="add">
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>

