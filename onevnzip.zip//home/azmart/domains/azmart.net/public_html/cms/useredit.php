<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}	
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	if($HTTP_GET_VARS["mode"] == "edit" && $HTTP_GET_VARS["pages"]=="user")
	{
		$id = $_GET["id"];
		$select_query = "SELECT fullname, user, pass,superuser, active FROM users WHERE user = '$id'";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$fullname = $row["fullname"];
		$user = $row["user"];
		$superuser = $row["superuser"];
		$passtemp = $row["pass"];
		$active = $row["active"];					
	}
	
	if($HTTP_POST_VARS["mode"] == "edit" && isset($HTTP_POST_VARS["mode"]) && $HTTP_POST_VARS["pages"] == "user")
	{
		
		$id = $_POST["id"];
		$fullname 	= convert_font($_POST["fullname"]);
		$user 		= $_POST["user"];
		$oldpass 	= trim($_POST["oldpass"]);
		$pass 		= trim($_POST["pass"]);
		$repass 	= trim($_POST["repass"]);
		$passtemp   = $_POST["passtemp"];
		$superuser  = $_POST["superuser"];
		$active 	= isset($_POST["active"]) ? $_POST["active"] : 0;
		if($superuser==1) $active=1;
		
		if($fullname		== "") $message1 = $message1."<li/>Hãy nhập tên nhân viên quản trị";
		if($user 			== "") $message1 = $message1."<li/>Hãy nhập tên đăng nhập";

		if($massage1=="" && $user!=$id)
		{
			$check_query = "SELECT user FROM users WHERE user = '$user'";
			$sql->query($check_query);
			if($sql->num_rows()>0){
				$message1 = "<li/>Nhân viên quản trị này đã có. Nhập tên đăng nhập mới hoặc giữ tên đăng nhập cũ";			
				$user = $id;
			}
		}		

		if($HTTP_SESSION_VARS["super"]==0 || $superuser==1){
			if($oldpass 		== "") $message1 = $message1."<li/>Hãy nhập mật khẩu cũ để xác nhận việc cập nhật thông tin";	
				else	if(md5($oldpass) != $passtemp)
					$message1 = $message1."<li/>Mật khẩu cũ nhập không chính xác. Bạn hãy nhập lại";	
		}
		if(strlen($pass) <  4 && strlen($pass) >=1) $message1 = $message1."<li/>Mật khẩu phải ít nhất là 4 ký tự";	
		if($pass		 != $repass && strlen($pass)>=4 ) $message1 = $message1."<li/>Mật khẩu mới nhập không chính xác. Bạn hãy nhập lại";	
		
		if($message1 == "" && $pass == $repass && strlen($pass)>=4)
			$pass = md5($pass);	
		else
			if($message1 == "") $pass= $passtemp;			
		if($message1 ==""){			
			$fullname = convert_font($_POST["fullname"],2);
			$update_query = "UPDATE users SET fullname = '$fullname', user = '$user', pass = '$pass', active = $active WHERE user = '$id'";			
			if($sql->query($update_query)){
				$sql->close();
				$message = "<li>Update Successfull !";
				if($HTTP_SESSION_VARS['super']==0) $HTTP_SESSION_VARS['user'] = $user;				
				require_once("user.php");
				exit();
			}			
		}
	}	
?>

<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<META content="DEMO - Thuong mai dien tu - Kinh doanh tren Internet - Quang ba san pham..." name=keywords>
<META content="DEMO" name=description>
<LINK href="../style/mstyle.css" rel=stylesheet type=text/css>
<script language='Javascript' src='viettyping.js'></script>
<title>-- Add User --</title>
</head>
<body><div align="center">
	<table width="780" border="0" align="center" cellpadding="2" cellspacing="0">
	<tbody>
	  <tr>
	    <td width="143" align="center" bgcolor='whitesmoke' class="logout">[ <a href="index.php?pages=logout">Logout</a> ]</td>
	    <td align="center" bgcolor='whitesmoke' class="menu_bar_manager"><?=$detail = $HTTP_SESSION_VARS["super"]==1 ? "[ <a href='index.php?pages=user&mode=add'>Add User</a> ] [ <a href='index.php?pages=user'>Manager User</a> ][ <a href='index.php?pages=user&mode=detail'>History</a> ]" : ''?></td>
      </tr>
	  </tbody>
</table> 
	
	
      <table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td bgcolor='whitesmoke' width="147" height="669" valign="top"><?php include("menu.php"); ?></td>
     <td width="633" align="right" valign="top">
  </form>
	<center>	<div align="center">
	  <br>
	  <TABLE cellSpacing=0 cellPadding=2 width=550 align=center 
            border=0>
        <TBODY>
          <TR>
            <TD width="50" 
                ><A 
                  style="COLOR: navy; TEXT-DECORATION: none" 
                  href="index.php?pages=user"><IMG 
                  height=15 alt="Back Categories" src="../images/back.gif" 
                  width=15 border=0></A></TD>
            <TD width="492" 
                >&nbsp;</TD>
          </TR>
        </TBODY>
	    </TABLE>
	  <FORM action=index.php method=post enctype="multipart/form-data" name="useradd" id="useradd">
        <TABLE borderColor=whitesmoke cellSpacing=0 cellPadding=2 
            width=550 align=center border=1>
          <TBODY>
            <TR bgColor=whitesmoke>
              <TD class="header_table" 
                >Edit User </TD>
            </TR>
            <TR>
              <TD class="header_table" 
                ><BR>
      &nbsp;
                <TABLE cellSpacing=0 cellPadding=2 width=350 
                  align=center border=0>
                  <TBODY>
                    <TR>
                      <TD class="header_table" 
                      >Full Name:</TD>
                      <TD align=left colSpan=3><INPUT name=fullname class="input_f2" id="fullname" value="<?=$fullname?>"></TD>
                      </TR>
                    <TR>
                      <TD class="header_table" 
                      >User Name:</TD>
                      <TD align=left colSpan=3><INPUT name=user class="input_f2" id="user" value="<?=$user?>"></TD>
                      </TR>
                    <TR>
                      <TD class="header_table" 
                      >Old Pass </TD>
                      <TD align=left colSpan=3><INPUT name=oldpass type="password" class="input_f2" id="oldpass" value="<?=$oldpass?>">
                        <input name="passtemp" type="hidden" id="passtemp" value="<?=$passtemp?>"></TD>
                    </TR>
                    <TR>
                      <TD class="header_table" 
                      >New Pass:</TD>
                      <TD align=left colSpan=3><INPUT name=pass type="password" class="input_f2" id="pass" value="<?=$pass?>"></TD>
                    </TR>
                    <TR>
                      <TD class="header_table" 
                      >  Re New Pass:</TD>
                      <TD align=left colSpan=3><INPUT name=repass type="password" class="input_f2" id="repass" value="<?=$repass?>"></TD>
                      </TR>
					<TR>
                      <TD 
                      width=87 class="header_table" 
                      >Active:</TD>
                      <TD align=left colSpan=3><input name="active" type="checkbox" id="active" value="1" <?=$check=$active==1 ? 'checked' : ''?>></TD>
                    </TR>
                    <TR>
                      <TD 
                       
                      width=87>&nbsp;</TD>
                      <TD width=113 
                       
                      align=right class="manager_link"><input style="BORDER-RIGHT: #4565b4 1px solid; BORDER-TOP: #4565b4 1px solid; FLOAT: left; BORDER-LEFT: #4565b4 1px solid; BORDER-BOTTOM: #4565b4 1px solid; FONT-FAMILY: Arial; BACKGROUND-COLOR: #ffffff" type=submit value=Update name=submit></TD>
                      <TD 
                       
                      align=right width=124>
                        <P align=center>&nbsp;</P></TD>
                      <TD width="10" 
                       
                      align=right>
                        <P 
                align=center>&nbsp;</P></TD>
                      </TR>
                  </TBODY>
                </TABLE>
                <BR>
      <?php if($message!="") echo "<br>".$message; if($message1!="") echo "<br>".$message1; ?></TD>
            </TR>
          </TBODY>
        </TABLE>
        <br>
        <input name="pages" type="hidden" id="pages" value="user">
        <input name="mode" type="hidden" id="mode" value="edit">
        <input name="id" type="hidden" id="id" value="<?=$id?>">
        <input name="superuser" type="hidden" id="superuser" value="<?=$superuser?>">
      </FORM>
	  <p align="center">&nbsp;</p>
	  </div></td>
        </tr>
</table> 
</div></body>
</html>