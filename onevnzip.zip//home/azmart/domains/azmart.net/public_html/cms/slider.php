<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	if(session_is_registered('countadd'))
	{
		$HTTP_SESSION_VARS['countadd']=0;
	}

	$select_query = "SELECT * FROM slider ORDER BY thutu  ";
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	$sql->query($select_query);
	$n = $sql->num_rows();
	$_list = slider;			
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
	function delSlider(id) {
		if (confirm("Are you sure ?" )) {
			window.location.replace("index.php?pages=slider&mode=del&id=" + id);			
		}
	}	
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=slider">Quảng lý ảnh Slider </a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>";?>
      <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Quảng lý ảnh Slider (<?=$n?>) </h1>
      <div class="buttons"><a onclick="location = 'index.php?pages=slider&mode=add'" class="button">Thêm</a><a class="button">Delete</a></div>
    </div>

    <div class="content">
        <? if($n>0){?>
        <table class="list">
          <thead>
            <tr>
              <td class="left">Thứ tự</td>
              <td class="left">Logo</td>
              <td class="left">Content</td>
              <td class="left">Link</td>
              <td class="left">Position</td>
              <td class="left">Publish</td>
              <td class="right">Công cụ</td>
            </tr>
          </thead>
          <tbody>
              <?php
                    for($i=1; $i<$n+1; $i++){
			$tt = $tt + 1;
			$rows = $sql->fetch_array();
			$id = $rows['id'];
			$logo		= $rows["logo"] <> "" ? "<img src='".$dir_imgslider.$rows["logo"]."'  width='200' style='border: 1px solid #000000; padding-left: 0; padding-right: 0; padding-top: 0px; padding-bottom: 0px'>" : 'Doi tac này chưa có ảnh';
			$content	= $rows['content'];
			$position	= $rows['position'];
			$publish	= $rows['publish'];
			$link           =$rows['link'];
		?>
            <tr>
              <td class="left"><?= $tt ?></td>
              <td class="left"><?= $logo ?> </td>
              <td class="left"><?= $content ?></td>
              <td class="left"><?= $link ?></td>
              <td class="left"><?= ($position == "left" ? "Left":"Right") ?></td>
              <td class="left"><?= ($publish == "1" ? "Yes":"No") ?></td>
              <td class="right"> <a href="index.php?pages=slider&mode=edit&id=<?= $id ?>"> <img border="0" alt="Edit" src="../images/edit_button.gif" width="36" height="13"></a>
                                 <a class="openl" onClick="delSlider(<?=$id ?>)"> <img height="13" alt="Delete" src="../images/del_button.gif" width="36" border="0"></a>
                </td>
            </tr>
            	<?php 
		} $sql->close();
		?>

        </tbody>
        </table>
        <? }else echo "<br><div align=center>Chưa có nhà sản xuất nào trong CSDL !</div>";?>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>