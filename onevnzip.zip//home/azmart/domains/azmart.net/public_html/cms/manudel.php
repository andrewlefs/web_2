<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	
	if ($HTTP_GET_VARS["mode"]=="del" && $HTTP_GET_VARS["pages"]=="manu")
	{
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();	
		$id = $_GET["id"];
                $select = "select anh from nsx where nsxid= $id";
                $sql->query($select);
                if($row = $sql->fetch_array()){
                    $ha = $row["anh"];
                }
                
                if(!empty($ha)){
                    $path = $dir_imglogos.$ha;
                   if(file_exists($path))	unlink("$path");	
                }
                
		if(is_numeric($id)){
			$delete_query = "DELETE FROM nsx WHERE nsxid = $id";
			$sql->query($delete_query);				
			if($sql->check_del()){
				$message= "Xóa thành công !";
				$sql->close();
				require_once("manu.php");
				exit();
			}
			else{
				$message= "Kh&ocirc;ng c&oacute; m&#7909;c b&#7841;n c&#7847;n x&oacute;a !";
				$sql->close();
				require_once("manu.php");
				exit();
			}			
		}
		else{
			$message= "Kh&ocirc;ng c&oacute; m&#7909;c b&#7841;n c&#7847;n x&oacute;a !";
			$sql->close();
			require_once("manu.php");
			exit();
		}			
	}
?>