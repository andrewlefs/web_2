<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}	
	if($HTTP_POST_VARS["mode"] == "add" && isset($HTTP_POST_VARS["mode"]) && $HTTP_POST_VARS["pages"] == "gia")
	{
		if(!session_register('countadd'))
		{
			session_register('countadd');
			$HTTP_SESSION_VARS['countadd']=0;
		}		
		$name = convert_font($_POST["name"]);
		$from = convert_font($_POST["price_from"]);
                $to = convert_font($_POST["price_to"]);
		$message1 = $name == "" ? "Hãy nhập tên khoảng giá" : "";
		$message1.= $from == "" ? "Hãy nhập giá từ" : "";
                $message1.= $to == "" ? "Hãy nhập giá đến" : "";
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();	
		if($message1 =="")		
		{			
			$name = convert_font($_POST["name"],2);
			$insert_query = "INSERT INTO khoanggia(name,price_from,price_to) VALUES('$name','$from','$to')";			
			if($sql->query($insert_query))
			{			
				$HTTP_SESSION_VARS['countadd'] = $HTTP_SESSION_VARS['countadd'] + 1;				 
				$message = "Thông tin về  khoảng giá thứ  ".$HTTP_SESSION_VARS['countadd']." đã được thêm vào CSDL";			
				unset($name);
			}	
							
		}
	}	
?>
<?php include("lib/header.php")?>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=gia">Quản lý khoảng giá</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='warning'>Success: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Thêm khoảng giá</h1>
      
      <form action=index.php method=post enctype="multipart/form-data" name="giaadd" id="giaadd" >
      <div class="buttons"><input type="submit" value="Thêm" name="submit" class="submit1" ><a onclick="location = ''" class="button">Cancel</a></div>
    </div>
    <div class="content">
      

        <div id="tab-general">
         
                    <div id="language1">
            <table class="form">
              <tr>
                <td><span class="required">*</span> Tên khoảng giá:</td>
                <td><input type="text" name="name" size="100" id="name" value="<?=$name?>" />
                  </td>
              </tr>
             <tr>
                <td><span class="required">*</span> Giá từ:</td>
                <td><input type="text" name="price_from" size="100" id="price_from" value="<?=$from?>" />
                  </td>
              </tr>
              <tr>
                <td><span class="required">*</span> Giá đến:</td>
                <td><input type="text" name="price_to" size="100" id="price_to" value="<?=$to?>" />
                  </td>
              </tr>   
            </table>
          </div>
       </div>
        <input type="hidden" value="Add" name="submit">
        <input name="pages" type="hidden" id="pages" value="gia">
        <input name="mode" type="hidden" id="mode" value="add">
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>
