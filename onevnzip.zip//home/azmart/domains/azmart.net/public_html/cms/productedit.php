<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	
	$sql = new db_sql();
	$sql->db_connect();	
	$sql->db_select();
        if($HTTP_GET_VARS["mode"] == "edit" && $HTTP_GET_VARS["pages"]=="product"){
            $id = $HTTP_GET_VARS["id"];
            $select_query = "SELECT  ten ,gia ,anh ,km ,thongso,mota,noibat,moi,hienthi_trangchu, album,tinhtrang,xuatxu,nsxid,catid,subcatid FROM sanpham WHERE SanphamID =$id";
            $sql->query($select_query);
            $row = $sql->fetch_array();		
            $ten 	= $row["ten"]; 
            $xuatxu = $row["xuatxu"];
            $tinhtrang  = $row["tinhtrang"];
            $gia        = $row["gia"]; 	   
            $khuyenmai  = $row["km"];		
		$anh1 = $row["album"];
                $tempimg2   = $row["album"];
                $noibat     = $row["noibat"]; 
                $catid_edit  = $row["catid"];
                $subcatid_edit = $row["subcatid"];
                $hienthi_trangchu = $row["hienthi_trangchu"];            
                $mota 		= $row["mota"]; 
                $thongso 	= $row["thongso"];                                                              
		$anhcu 		= $row["anh"] <> "" ? "<img src='".$dir_imgproducts.$row["anh"]."' style='border: 1px solid #000000; padding-left: 0; padding-right: 0; padding-top: 0px; padding-bottom: 0px' onClick=OpenNewWindow('../comm/imagesviewer.php?img=".$dir_imgproducts."origin/".$row["anh"]."&mode=back',500,500)>" : 'Chưa có ảnh SP';
		$imgtemp 	= $row["anh"];
		$position_page = $_GET["position_page"];
			
        }	
	if($HTTP_POST_VARS["mode"] == "edit" && isset($HTTP_POST_VARS["mode"]) && $HTTP_POST_VARS["pages"] == "product"){
                $id1 = $_POST["idsp"];
		$ten 		= isset($_POST["ten"])		? convert_font($_POST["ten"])		: '';             
                $xuatxu 	= isset($_POST["xuatxu"])	? convert_font($_POST["xuatxu"])	: '';       
		$subcatid 	= isset($_POST["subcatid"]) 	? $_POST["subcatid"]			: 0;           
		$gia	 	= isset($_POST["gia"])		? $_POST["gia"]				: 0;	
                $catid          = $_POST["catid"];
		$moi1	 	= isset($_POST["moi"]) 		? $_POST["moi"]				: 0;
                $tinhtrang1	= isset($_POST["tinhtrang"]) 	? $_POST["tinhtrang"]			: 0;
                $khuyenmai	= isset($_POST["khuyenmai"]) 	? $_POST["khuyenmai"]			: 0;
		$noibat 	= isset($_POST["noibat"]) 	? $_POST["noibat"]			: 0;
		$mota	 	= isset($_POST["mota"])		? convert_font($_POST["mota"])		: '';
		$thongso 	= isset($_POST["thongso"])	? convert_font($_POST["thongso"])	: '';				
		$anh 		= isset($_FILES["anh"]["name"]) ? $_FILES["anh"]["name"]			: '';		
                $album1         = isset($_FILES["album1"]["name"])?$_FILES["album1"]["name"]:"";
		$anhcu 		= $_POST["anhcu"] <> "" ? stripslashes($_POST["anhcu"]) : '';
		$imgtemp 	= $_POST["imgtemp"];
                $tempimg3       = $_POST["tempimg"];
                $position_page  = $_POST["position_page"];
                $hienthi_trangchu	 	= isset($_POST["hienthi_trangchu"]) 		? $_POST["hienthi_trangchu"]				: 0;
                                                    
		if($ten			 	== "") $message1 = $message1."Hãy nhập tên SP";
		if($gia 			== 0 || !is_numeric($gia)) $message1 = $message1."Hãy nhập giá SP và giá phải là số";		
		if($mota		 	== "") $message1 = $message1."Hãy nhập nội dung mô tả SP";
		if($thongso		 	== "") $message1 = $message1."Hãy nhập các thông số của SP";
	
		//bat dau thuc hien upload anh SP len thu muc tren may chu WEB		
		if (!empty($anh)){
		$filename = "";
	       	$start = strpos($anh,".");
                $type  = substr($anh,$start,strlen($anh));
                if ((strtolower($type)!=".gif")&&(strtolower($type)!=".jpg")){
                $message1 = "Tệp ảnh phải có kiểu tệp là .jpg hoặc .gif";             
	        }
                if($message1==""){
                $filename = time().$type;
                        if (!copy($_FILES['anh']['tmp_name'], $dir_imgproducts."origin/".$filename)) die ("Cannot upload file.");
                        thumb($_FILES['anh']['tmp_name'], $dir_imgproducts.$filename, $ratio_image_width, $ratio_image_width, false);
                        $file_path = $dir_imgproducts."origin/".$imgtemp;
                        if($imgtemp!="" && file_exists($file_path))	unlink($file_path);
                        $file_path = $dir_imgproducts.$imgtemp;
                        if($imgtemp!="" && file_exists($file_path))	unlink($file_path);
                }
	    }else{
			if(empty($anh)) $filename=$imgtemp;
		}
                
                     $tenfile = "";
                    if(!empty($album1[0])){                    
                        for($i=0;$i<count($album1);$i++){
                              $temp = $_FILES["album1"]["name"][$i];
                              $start = strpos($temp,".");
                              $type = substr($temp,$start,  strlen($temp));
                              $ten_anh = substr($temp,0,$start);
                              $ten_anh = cut_space(catdau_admin($ten_anh));
                              if(strtolower($type)!=".jpg" && strtolower($type)!=".gif"){
                                  $message1 = "Tệp ảnh phải có kiểu tệp là .jpg hoặc .gif"; 
                              }else{
                                          if($message1==""){
                                                          $filename1 = time()."-".$i."-".$type;
                                                          if (!copy($_FILES['album1']['tmp_name'][$i], $dir_imgproducts."origin/".$filename1)) die ("Cannot upload file.");
                                                          thumb($_FILES['album1']['tmp_name'][$i], $dir_imgproducts.$filename1, $ratio_image_width, $ratio_image_width, false);
                                                          for($k=0;$k<count($tempimg1)-1;$k++){
                                                            $file_path = $dir_imgproducts."origin/".$tempimg1[$k];
                                                             if($tempimg1[$k]!="" && file_exists($file_path))	unlink($file_path);
                                                             $file_path = $dir_imgproducts.$tempimg1[$k];
                                                             if($tempimg1[$k]!="" && file_exists($file_path))	unlink($file_path);
                                                          }
                                           }
                                      }
                                    $tenfile = $tenfile.$filename1.";";  
                        }
                }else {
                        if(empty($album1[0]))  {                           
                            $tenfile = $tempimg3;
                        }
                }
                
    
		//Bat dau chen DL vao CSDL		
		if($message1 ==""){			
			$ten 		= isset($_POST["ten"])			? convert_font($_POST["ten"],2)			: '';
               
			$gia	 	= isset($_POST["gia"])			? $_POST["gia"]					: 0;
                       
			
			$mota	 	= isset($_POST["mota"])			? convert_font($_POST["mota"],2)		: '';
			$thongso 	= isset($_POST["thongso"])		? convert_font($_POST["thongso"],2)		: '';					
			
			$update_query = "UPDATE sanpham SET ten='$ten', catid='$catid',subcatid='$subcatid', gia='$gia',anh='$filename', moi='$moi1', km='$khuyenmai', noibat='$noibat', mota='$mota', thongso='$thongso',hienthi_trangchu='$hienthi_trangchu',album='$tenfile',  
			tinhtrang='$tinhtrang1'  WHERE SanphamID = $id1";
						
			if($sql->query($update_query)){
				$sql->close();
				$message = $message."Cập nhật thành công !";
				include_once("product.php");
				exit();
			}		
		}
	}		
?>
<?php include("lib/header.php")?>
<div id="content">
  <div class="breadcrumb">
     <a href="/">Home</a>
         :: <a href="index.php?pages=product&cat=<?=$catid?>">Danh mục:: <?=get_catname($catid)?> </a>
        </div>
        <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='warning'>Warning: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/product.png" alt="" /> <?=get_catname($catid)?></h1>
      <form action=index.php method=post enctype="multipart/form-data" name="editproduct" id="editproduct">
      <div class="buttons"><input type="submit" value="Update" name="submit" class="submit1" ><input type="reset" value="Làm lại" name="submit2" class="submit1" ></div>
    </div>
    <div class="content">
      <div id="tabs" class="htabs"><a href="#tab-general">Thông tin chung</a><a href="#tab-data">Thống số</a>
      </div>
     <div id="tab-general">
        <div id="language1">
            <table class="form">
                <tr>
                    <td>Danh mục sản phẩm<span class="required">*</span>:</td>
                    <td>
                        <select name="catid" id="catid">                           
                            <?php
                                for($i=1;$i<=count($cat);$i++){
                                    if($cat[$i]["catid"]==$catid_edit){?>
                                    <option value="<?=$cat[$i]["catid"]?>" selected><?php echo $cat[$i]["catname"];?></option>
                                <?}else{?>
                                    <option value="<?=$cat[$i]["catid"]?>"><?php echo $cat[$i]["catname"];?></option>
                                <?}
                                }
                            ?>
                        </select>
                    </td>
                </tr>
                
                 <tr>
                    <td>Danh mục sản phẩm con<span class="required">*</span>:</td>
                    <td>
                      
                        <select name="subcatid" id="subcatid">                           
                            <?php
                                for($j=1;$j<=count($subcat);$j++){
                                    if($subcat[$j]["subcatid"]==$subcatid_edit){?>
                                    <option value="<?=$subcat[$j]["subcatid"]?>" selected><?php echo $subcat[$j]["subcatname"];?></option>
                                <?}else{?>
                                    <option value="<?=$subcat[$j]["subcatid"]?>"><?php echo $subcat[$j]["subcatname"];?></option>
                                <?}
                                }
                            ?>
                        </select>

                    </td>
                </tr>
                
              <tr>
                <td>Tên sản phẩm <span class="required">*</span> :</td>
                <td><input type="text" name="ten" name="ten" size="100" value="<?=$ten?>" />
                  </td>
              </tr>                     
              <tr>
                    <td>Giá sản phẩm <span class="required">*</span> :</td>
                    <td><input type="text" name="gia" name="gia" value="<?=$gia?>" />
                    </td>
              </tr>            
              
           <!--   <tr>
                <td>Nhà sản xuất<span class="required">*</span> :</td>
                <td>
                    <select name="nsx">
                        <?for($i=1;$i<=count($dm_nsx);$i++){
                            if($dm_nsx[$i]["nsxid"]==$nsx_edit){?>
                            <option value="<?=$dm_nsx[$i]['nsxid']?>" selected><?=$dm_nsx[$i]['tennsx']?></option>
                        <?}else{?>
                            <option value="<?=$dm_nsx[$i]['nsxid']?>"><?=$dm_nsx[$i]['tennsx']?></option>
                        <?}
                        }?>
                    </select>
                  </td>
              </tr>      --> 
             <tr>
                <td>Ảnh cũ:</td>
                <td> <?=$anhcu?>
                  </td>
              </tr> 
                   <tr>
                <td>Ảnh đại diện  :<br />(Bạn có thể chọn một ảnh mới làm ảnh đại diện)</td>
                <td> <input name="anh" type="file" id="anh" value="<?=$anh?>" size="32">
                  </td>
              </tr>                
                <tr>
                  <td>Thêm ảnh sản phẩm (Bạn có thể chọn nhiều ảnh cho sản phẩm):</td>
                  <td>
                      <input type="file" name="album1[]" id="album" value="<?=$album1?>" size="32" multiple="true"/>
                  </td>
              </tr>        
            
             <tr>
              <td>Tình trạng</td>
              <td> 
                  <input  type="text" name="tinhtrang" value="<?=$tinhtrang?>">                   
                </td>
            </tr>
               <tr>
                <td>Hiển thị trang chủ:</td>
                <td>  <input name="hienthi_trangchu" value="1" <?=$hienthi_trangchu==1?"checked":""?> type="radio">Đúng
                      <input name="hienthi_trangchu" value="0" type="radio" <?=$hienthi_trangchu==0?"checked":""?>>Sai
                  </td>
              </tr>
              <tr>
              <td>SP nổi bật:</td>
              <td>  <input name="noibat" value="1" checked="checked" type="radio">Đúng
                    <input name="noibat" value="0" type="radio">Sai
                </td>
            </tr>            
              
               <tr>
              <td>Thông tin khuyến mại:</td>
              <td>
                  <textarea name="khuyenmai" rows="10" cols="40" style="width:99%"><?=$khuyenmai?></textarea>
                   
                </td>
            </tr>
            </table>
          </div>
     </div>
        <div id="tab-data">
          <table class="form">
              <tr>
                <td>Mô tả:</td>
                <td><textarea id="elm1" name="mota" rows="20" cols="40" style="width:99%"><?=$mota?></textarea></td>
              </tr>
             <tr>
                <td>Thông số:</td>
                <td><textarea id="elm2" name="thongso" rows="20" cols="40" style="width:99%"><?=$thongso?></textarea></td>
              </tr>
          </table>
        </div>
        <input name="pages" type="hidden" id="pages" value="product">        
        <input name="mode" type="hidden" id="mode" value="edit">
        <input name="catid" type="hidden" id="catid" value="<?=$catid?>">
          <input name="anhcu1" type="hidden" id="mode3" value="<?=$anh1?>">
        <input name="tempimg" type="hidden" id="mode4" value="<?=$tempimg2?>">
        <input name="anhcu" type="hidden" id="mode3" value="<?=$anhcu?>">
        <input name="imgtemp" type="hidden" id="mode3" value="<?=$imgtemp?>">
        <input name="idsp" type="hidden" id="idsp" value="<?=$id?>">
        <input name="position_page" type="hidden" id="sachid_old" value="<?=$position_page?>">
      </form>
    </div>
  </div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>