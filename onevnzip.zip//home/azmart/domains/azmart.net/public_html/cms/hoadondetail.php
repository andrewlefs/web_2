<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();

	if($HTTP_GET_VARS[mode] == "detail")
	{
		$id = $_GET["id"];
		$select_query = "SELECT sanpham_id, sanpham_soluong, noi_dung, ky_danh FROM hoa_don WHERE id = $id limit 1";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$sanpham_id = $row["sanpham_id"];
		$sanpham_soluong = $row["sanpham_soluong"];
                                                    $noidung = $row["noi_dung"];
		$kydanh = $row["ky_danh"];
		$n = $sql->count_rows("hoa_don");	
	}
        
                    if($HTTP_POST_VARS[mode] == "detail" && $HTTP_POST_VARS["pages"]=="hoadon")
                    {
                                  $id = $_POST["id"];       
                                  $delete_query = "DELETE FROM hoa_don WHERE id = $id";
                                $sql->query($delete_query);	
                                $message= "<li>Xóa thành công !";
                                require_once("hoadon.php");
                                exit();
                    }
                    $sp_id = explode(";", $sanpham_id);
                    $sp_sl = explode(";", $sanpham_soluong);	
              
?>

<?php include("lib/header.php")?>
<div id="content">
<div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=hoadon">Quản lý danh mục </a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='success'>Success: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" /> Chi tiết hóa  đơn</h1>
      <form action=index.php method=post enctype="multipart/form-data" name="hoadondel" id="hoadondel">
                <div class="buttons">
                      <input type="submit" value="Xóa" name="submit" class="submit1" > 
                      <a onclick="location = ''" class="button">Cancel</a></div>
              </div>
        
            <div class="content">        
                <table class="list">
                  <thead>
                    <tr>             
                     
                      <td class="left">Người gửi</td>
                      <td class="left">Email</td>
                      <td class="left">Điện thoại</td>
                       <td class="left">Ghi chú</td>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>                        
                      <td class="left"><?=  get_intro_fullname($kydanh)?> </td>
                      <td class="left"><?=  get_intro_email($kydanh)?> </td>
                      <td class="left"><?=  get_intro_phone($kydanh) ?> </td>         
                      <td class="left"><?=  $noidung ?> </td>  
                    </tr>
                </tbody>
                </table>
                <table class="list">
                  <thead>
                    <tr>
                      <td class="left">Thứ tự</td>
                      <td class="left">Tên sản phẩm</td>
                      <td class="left">Giá bán</td>       
                      <td class="left">Số lượng</td>
                      <td class="left">Tổng cộng</td>             
                    </tr>
                  </thead>
                  <tbody>
                      <?php

                        for($i=0; $i< count($sp_id)-1; $i++){
                            $tt = $tt + 1;                
                            $id = $sp_id[$i];
                            $temp = get_intro_sanpham($id);
                            $tc=$sp_sl[$i]*$temp['gia'];
                            $tcl=$tcl+$tc;

                    ?>
                    <tr>          
                      <td class="left"><?= $tt ?></td>
                      <td class="left"><?=$temp["ten"] ?> </td>          
                      <td class="left"><?=  number_format($temp["gia"])?> </td>
                      <td class="left"><?=$sp_sl[$i]?> </td>
                      <td class="left"><?=number_format($temp["gia"]*$sp_sl[$i])?> </td>
                    </tr>
                        <?php 
                        } 
                        ?>
                    <tr>
                        <td colspan="6" style="text-align: right"><?=  number_format($tcl)?></td>
                    </tr>
                </tbody>
                </table>
                 <input name="pages" type="hidden" id="pages" value="hoadon">
                <input name="mode" type="hidden" id="mode" value="detail">
                <input name="id" type="hidden" id="id" value="<?=$id?>">
              </form>
            </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>

