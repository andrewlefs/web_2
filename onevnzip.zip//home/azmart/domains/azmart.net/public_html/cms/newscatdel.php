<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	
	if ($HTTP_GET_VARS["mode"]=="del" && $HTTP_GET_VARS["pages"]=="newscat" )
	{
		$anhsp = array();
		$id = $_GET["id"];
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
				
		//Count product of cat		
		$select_query = "SELECT anhtin FROM tintuc WHERE newscat_id = $id";
		$sql->query($select_query);
		while($row = $sql->fetch_array()){
			$i=$i+1;
			$anhsp[$i]["anhtin"] = $row["anhtin"];
		}
		$n = $sql->num_rows();
		if($n>0){		
			$delete_query = "DELETE FROM tintuc WHERE newscat_id = $id";
			$sql->query($delete_query);			
			for($i=1; $i<=count($anhsp);$i++){	
				$anhtin = $anhsp[$i]["anhtin"];		
				if(!empty($anhtin)){
					$file_path = $dir_imgproducts.$anhtin;
					if(file_exists($file_path))	unlink("$file_path");
				}
			}
			$delete_query = "DELETE FROM newscat WHERE id = $id";
			$sql->query($delete_query);	
			$sql->close();
			$message= "Xóa thành công !";
			require_once("newscat.php");
			exit();
		}
		else{
			$delete_query = "DELETE FROM newscat WHERE id = $id";
			$sql->query($delete_query);	
			$sql->close();
			$message= "Xóa thành công !";
			require_once("newscat.php");
			exit();
		}					
	}
?>