<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	if(session_is_registered('countadd'))
	{
		$HTTP_SESSION_VARS['countadd']=0;
	}
	//Hien thi thong tin ve chu hóa đơn
	$select_query = "SELECT id, sanpham_id, sanpham_soluong,noi_dung,ky_danh FROM hoa_don ORDER BY id";
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	$sql->query($select_query);
	$n = $sql->num_rows();	
	$sql->close();
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
    function delCate(id) {
		if (confirm("Bạn có muốn xóa thật không ? Nếu bạn xóa danh mục này thì tất cả sản phẩm thuộc danh mục cũng bị xóa theo." )) {
			window.location.replace("index.php?pages=hoadon&mode=del&id=" + id);			
		}
	}
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=hoadon">Quản lý danh mục </a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>";?>
      <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Danh sách hóa đơn (<?=$n?>) </h1>
      <div class="buttons"><!--<a onclick="location = 'index.php?pages=hoadon&mode=add'" class="button">Thêm</a>--><a class="button">Delete</a></div>
    </div>

    <div class="content">
        <? if($n>0){?>
        <table class="list">
          <thead>
            <tr>
              <td width="1" style="text-align: center;"><input type="checkbox" onclick="$('input[name*=\'selected\']').attr('checked', this.checked);" /></td>
              <td class="left">Thứ tự</td>
                     <td class="left">Ký danh</td>
              <td class="left">Người gửi</td>
       
              <td class="left">Email</td>
              <td class="left">Điện thoại</td>
               <td class="left">Ghi chú</td>
              <td class="right">Công cụ</td>
            </tr>
          </thead>
          <tbody>
              <?php
                for($i=1; $i<=count($hoadon); $i++){
                    $tt = $tt + 1;
                    $hoadonid 		= $hoadon[$i]['id'];
                    $sanpham_id 	= $hoadon[$i]['sanpham_id'];
                    $soluong = $hoadon[$i]["sanpham_soluong"];
                    $kydanh = $hoadon[$i]["ky_danh"]; 
                      $noidung = $hoadon[$i]["noi_dung"]; 
            ?>
            <tr>
              <td style="text-align: center;"><input type="checkbox" name="selected[]" value="20" />
                </td>
              <td class="left"><?= $tt ?></td>
              <td class="left"><?=$kydanh ?> </td>          
              <td class="left"><?=  get_intro_fullname($kydanh)?> </td>
              <td class="left"><?=  get_intro_email($kydanh)?> </td>
              <td class="left"><?=  get_intro_phone($kydanh) ?> </td>         
              <td class="left"><?=  $noidung ?> </td>  
              <td class="right">[ <a href="index.php?pages=hoadon&mode=detail&id=<?=$hoadonid?>">Xem</a> ]
                                [ <a class="openl" onClick="delCate(<?=$hoadonid ?>)">Xóa</a> ]
                </td>
            </tr>
            	<?php 
		} 
		?>

        </tbody>
        </table>
        <? }else echo "<br><div align=center>Chưa có nhà sản xuất nào trong CSDL !</div>";?>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>
