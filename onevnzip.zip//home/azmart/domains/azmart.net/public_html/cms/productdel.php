<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}	
	if ($_GET["mode"]=="del" && $_GET["pages"]="product")
	{
                                                     if($_GET["act"]=="del") {
                                                                                                   $id = $_GET["id"];                                                                                               
                                                                                                    $delete_query = "DELETE FROM sanpham WHERE SanphamID = '$id'";
                                                                                                    $select_query = "SELECT anh  FROM sanpham WHERE SanphamID = '$id'";
                                                                                                    $select_query1 = "SELECT album  FROM sanpham WHERE SanphamID = '$id'";
                                                                                                    $album = array();
                                                                                                    $sql = new db_sql();
                                                                                                    $sql->db_connect();
                                                                                                    $sql->db_select();	
                                                                                                    $sql->query($select_query);	
                                                                                                   if($row = $sql->fetch_array()){
                                                                                                                $anh = $row["anh"];
                                                                                                    }                                                                                                  
                                                                                                   
                                                                                                    if(!empty($anh)) 
                                                                                                    {
                                                                                                                                    $file_path = $dir_imgproducts.$anh;                                                                                                                                    
                                                                                                                                    if(file_exists($file_path))	unlink("$file_path");
                                                                                                                                    $file_path = $dir_imgproducts."origin/".$anh;
                                                                                                                                    if(file_exists($file_path))	unlink("$file_path");                                                                                                          
                                                                                                    }
                                                                                                    
                                                                                                    $sql->query($select_query1);
                                                                                                    
                                                                                                    if($ro = $sql->fetch_array()){                                                                                                    
                                                                                                        $tem = $ro["album"];
                                                                                                    }
                                                                                                    
                                                                                                    $album = explode(";", $tem);
                                                                                                    
                                                                                                     for($i=0; $i<count($album)-2;$i++){	
                                                                                                                                       $file_path = $dir_imgproducts."origin/".$album[$i];
                                                                                                                                        if(file_exists($file_path))	unlink("$file_path");
                                                                                                                                        $file_path1 = $dir_imgproducts.$album[$i];
                                                                                                                                        if(file_exists($file_path1))	unlink("$file_path1");                                                                                                                         
                                                                                                        }	
                                                                                                        $sql->query($delete_query);
                                                                                                        $sql->close();
                                                                                                        $message= " Xóa thành công !";
                                                                                                        include_once("product.php");
                                                                                                        exit();
                                                    }else if($_GET["act"]=="upd") {
                                                                                                    $id = $_GET["id"];
                                                                                                    $update_query = "UPDATE sanpham  SET publish='".$_REQUEST["s"]."' WHERE sanphamid = '$id'";
                                                                                                    $sql = new db_sql();
                                                                                                    $sql->db_connect();
                                                                                                    $sql->db_select();	
                                                                                                    $sql->query($update_query);
                                                                                                    $sql->close();
                                                                                                    $message= "Đổi trạng thái thành công !";
                                                                                                    require_once("product.php");
                                                                                                    exit();
                                                 }
	}
	
		
	
?>
