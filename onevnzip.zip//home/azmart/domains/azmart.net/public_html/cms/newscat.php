<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	if(session_is_registered('countadd'))
	{
		$HTTP_SESSION_VARS['countadd']=0;
	}
	//Hien thi thong tin ve chu de sach
	$select_query = "SELECT id, title,publish FROM newscat ORDER BY list_order, title";
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	$sql->query($select_query);
	$n = $sql->num_rows();	
	$sql->close();
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
	function delCate(id) {
		if (confirm("Bạn có muốn xóa thật không ? Nếu bạn xóa danh mục này thì tất cả tin tức thuộc danh mục cũng bị xóa theo." )) {
			window.location.replace("index.php?pages=newscat&mode=del&id=" + id);			
		}
	}
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=newscat">Category</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>";?>
      <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Category (<?=$n?>) </h1>
      <div class="buttons"><a onclick="location = 'index.php?pages=newscat&mode=add'" class="button">Thêm</a><a onclick="$('#form').submit();" class="button">Delete</a></div>
    </div>

    <div class="content">
        <? if($n>0){?>
        <table class="list">
          <thead>
            <tr>
              <td class="tt">ID #</td>
              <td class="left">Category Name</td>
              <td class="left">Publish</td>
              <td class="right">Công cụ</td>
            </tr>
          </thead>
          <tbody>
             <?php
                for($i=1; $i<=count($newscat); $i++){
			$tt 	= $tt + 1;
			$id 	= $newscat[$i]['id'];
			$title 	= $newscat[$i]['title'];
			$publish = $newscat[$i]["publish"];
		?>
            <tr>
              <td class="tt"><?= $id ?></td>
              <td class="left"><?=$title ?></td>
              <td class="left"><?=$publish==1?"Có":"Không"?></td>
              <td class="right">[ <a style="CURSOR: hand" href="index.php?pages=newscat&mode=edit&id=<?=$id ?>">Sửa</a> ]
                                [ <a style="CURSOR: hand" onClick="delCate(<?=$id ?>)">Xóa</a> ]
                </td>
            </tr>
            <?php 
            } 
            ?>

        </tbody>
        </table>
        <? }else echo "<br><div align=center>Chưa có nhà sản xuất nào trong CSDL !</div>";?>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>