<?php
session_start();
require_once("config_tinybrowser.php");
require_once("fns_tinybrowser.php");

if (!isAdminAuth()) die('Access denied');
$_field = isset($_GET['_field'])?(string)$_GET['_field']:'';

// delay script if set
if($tinybrowser['delayprocess']>0) sleep($tinybrowser['delayprocess']);

// Initialise files array and error vars
$files = array();
$good = 0;
$bad = 0;
$dup = 0;
$total = (isset($_GET['filetotal']) ? $_GET['filetotal'] : 0);


// Assign get variables
$folder = $tinybrowser['docroot'].urldecode($_GET['folder']);
$passfeid = (isset($_GET['feid']) ? '&feid='.$_GET['feid'] : '');

if ($handle = opendir($folder))
{
	while (false !== ($file = readdir($handle)))
	{
		if ($file != "." && $file != ".." && substr($file,-1)=='_')
			{
			//-- File Naming
			$tmp_filename = $folder.$file;
			$dest_filename	 = $folder.rtrim($file,'_');
        
			//-- Duplicate Files
			if(file_exists($dest_filename)) { unlink($tmp_filename); $dup++; continue; }

			//-- Bad extensions
			$ext = end(explode('.',$dest_filename));
			if(!validateExtension($ext, $tinybrowser['prohibited'])) { unlink($tmp_filename); continue; }
			
			$_wh = @getimagesize($tmp_filename);
			//if (!is_array($_wh) || !isset($_wh[0]) || !isset($_wh[1]) || $_wh[0]==0 || $_wh[1]==0 || $_wh[0]>1000 || $_wh[1]>1000)
			if (is_array($_wh) && ($_wh[0]==0 || $_wh[1]==0 || $_wh[0]>3000 || $_wh[1]>3000))
			{
				unlink($tmp_filename); 
				continue;
			}
        
			//-- Rename temp file to dest file
			rename($tmp_filename, $dest_filename);
			$good++;
			
			//-- if image, perform additional processing
			if($_GET['type']=='image')
			{
				//-- Good mime-types
				$imginfo = getimagesize($dest_filename);
	   		if($imginfo === false) { unlink($dest_filename); continue; }
				$mime = $imginfo['mime'];

				// resize image to maximum height and width, if set
				if($tinybrowser['imageresize']['width'] > 0 || $tinybrowser['imageresize']['height'] > 0)
				{
					// assign new width and height values, only if they are less than existing image size
					$widthnew  = ($tinybrowser['imageresize']['width'] > 0 && $tinybrowser['imageresize']['width'] < $imginfo[0] ? $tinybrowser['imageresize']['width'] : $imginfo[0]);
					$heightnew = ($tinybrowser['imageresize']['height'] > 0 && $tinybrowser['imageresize']['height'] < $imginfo[1] ? $tinybrowser['imageresize']['height'] :  $imginfo[1]);

					// only resize if width or height values are different

					if($widthnew != $imginfo[0] || $heightnew != $imginfo[1])
					{
						try
						{
							$im = convert_image($dest_filename,$mime);
							if ($im)
							{
								resizeimage($im,$widthnew,$heightnew,$dest_filename,$tinybrowser['imagequality']);
							}
							
							@imagedestroy($im);						
						}
						catch (Exception $e)
						{
							die('Qqqq');
						}	
					}
					
				}
				// generate thumbnail
				$thumbimg = $folder."thumbs/_".rtrim($file,'_');
				if (!file_exists($thumbimg))
				{
					try
					{
						$im = convert_image($dest_filename,$mime);
						if ($im)
						{
							resizeimage	($im,$tinybrowser['thumbsize'],$tinybrowser['thumbsize'],$thumbimg,$tinybrowser['thumbquality']);
						}
						else
						{
							@unlink($tmp_filename);
							@unlink($dest_filename);
							@unlink($thumbimg);
						}
						
						@imagedestroy ($im);					
					}
					catch(Exception $e)
					{
						die('Wqqq');
						@unlink($tmp_filename);
						@unlink($dest_filename);
						@unlink($thumbimg);
						$good--;
					}
				}
			}
				
    }
	}
	closedir($handle);
}
$bad = $total-($good+$dup);



// Check for problem during upload
if($total>0 && $bad==$total) Header('Location: ./upload.php?type='.$_GET['type'].$passfeid.'&permerror=1&total='.$total.'&_field='.$_field);
else Header('Location: ./upload.php?type='.$_GET['type'].$passfeid.'&badfiles='.$bad.'&goodfiles='.$good.'&dupfiles='.$dup.'&_field='.$_field);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
		<title>TinyBrowser :: Process Upload</title>
	</head>
	<body>
		<p>You won't see this.</p>
	</body>
</html>
