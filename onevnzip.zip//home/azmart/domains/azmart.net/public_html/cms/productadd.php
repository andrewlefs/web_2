<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}                       
                 
        $CreateDate = date("Y-m-d");
        $nsx  = array();
        $sql = new db_sql();
        $sql->db_connect();	
        $sql->db_select();
        
        //lay mang hang sx
	$select_query = "SELECT nsxid, tennsx FROM nsx ORDER BY tennsx";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$i = $i + 1;
		$nsx[$i]["nsxid"]       = $rows["nsxid"];
		$nsx[$i]["tennsx"] 	= $rows["tennsx"];
	}
        
       if($HTTP_POST_VARS["mode"] == "add"  && $HTTP_POST_VARS["pages"] == "product"){
            if(!session_register('countadd')){
                    session_register('countadd');
                    $HTTP_SESSION_VARS['countadd']=0;
            }
            $ten            = isset($_POST["ten"])          ? $_POST["ten"]             : '';
            $acsii          = isset($_POST["ten"])          ? huu($_POST["ten"])             : '';
            $tinhtrang      = isset($_POST["tinhtrang"])    ? $_POST["tinhtrang"]	: "";
            $baohanh        = isset($_POST["baohanh"])      ? $_POST["baohanh"]		: "";
            $gia            = isset($_POST["gia"])          ? $_POST["gia"]		: 0;
            $gia            = is_numeric($_POST["gia"])     ? $gia:0;                                               
            $discount       = isset($_POST["discount"])     ? $_POST["discount"]	: 0;
            $xuatxu         = isset($_POST["xuatxu"])       ? $_POST["xuatxu"]		: 0;
            $thongso        = isset($_POST["thongso"])      ? convert_font($_POST["thongso"])	: '';
            $noibat         = isset($_POST["noibat"])       ? $_POST["noibat"]			: 0;
            $khuyenmai      = isset($_POST["khuyenmai"])    ? $_POST["khuyenmai"]			: 0;
            $mota           = isset($_POST["mota"])		? convert_font($_POST["mota"])		: '';
            $anh            = isset($_FILES["anh"]["name"])     ? $_FILES["anh"]["name"]		: '';
            $anhsp          = isset($_FILES["anhsp"]["name"])   ? $_FILES["anhsp"]["name"]		: '';
            $publish        = isset($_POST['publish'])          ? $_POST["publish"] : "1";
            $catid          = $_POST["catid"];
            $subcatid123    = $_POST["subcatid"];

            if($catid       == 0) $message1 = $message1."Hãy chọn danh mục sản phẩm";
            if($ten         == "") $message1 = $message1."Hãy nhập tên SP";
            if($mota        == "") $message1 = $message1."Hãy nhập nội dung mô tả SP";
            if($gia         =="")$message1=$message1."Giá sản phẩm phải là số";
          //  if($discount    == 0 || !is_numeric($discount)) $message1 = $message1."Hay nhập số % giảm giá";
            $hienthi_trangchu 	= isset($_POST["hienthi_trangchu"])? $_POST["hienthi_trangchu"]		: 0;

            //bat dau thuc hien upload anh SP len thu muc tren may chu WEB		
            if ( !empty($anh)){
                $filename = "";
                $start = strpos($anh,".");
                $type  = substr($anh,$start,strlen($anh));
                if ((strtolower($type)!=".gif")&&(strtolower($type)!=".jpg")){
                        $message1 = "Tệp ảnh phải có kiểu tệp là .jpg hoặc .gif";             
                }
                else{
                if($message1==""){
                      //  $filename = time().$type;
                        $filename = $acsii."-".time().$type;
                        if (!copy($_FILES['anh']['tmp_name'], $dir_imgproducts."origin/".$filename)) die ("Cannot upload file.");
                        thumb($_FILES['anh']['tmp_name'], $dir_imgproducts.$filename, $ratio_image_width, $ratio_image_width, false);
                }
                }
            }

          $tenfile="";
          if(!empty($anhsp)){
            $tenfile = "";
            for($i=0;$i<count($anhsp);$i++){
            $temp = $_FILES["anhsp"]["name"][$i];
            $start = strpos($temp,".");
            $type = substr($temp,$start,  strlen($temp));                                                                                                   
            if(strtolower($type)!=".jpg" && strtolower($type)!=".gif"){
                $message1 = "Tệp ảnh phải có kiểu tệp là .jpg hoặc .gif"; 
            }else{
                        if($message1==""){
                        //  $filename1 = time()."-".$i.$type;
                          $filename1 = $acsii."-".$i.$type;
                          if (!copy($_FILES['anhsp']['tmp_name'][$i], $dir_imgproducts."origin/".$filename1)) die ("Cannot upload file.");
                          thumb($_FILES['anhsp']['tmp_name'][$i], $dir_imgproducts.$filename1, $ratio_image_width, $ratio_image_width, false);
                         }
                    }
                    $tenfile = $tenfile.$filename1.";";
            }

       }
        //Bat dau chen DL vao CSDL	

        if($message1 ==""){			
                $ten        = isset($_POST["ten"])	? convert_font($_POST["ten"],2)		: '';
                $mota       = isset($_POST["mota"])	? convert_font($_POST["mota"],2)	: '';
                $thongso    = isset($_POST["thongso"])	? convert_font($_POST["thongso"],2)	: '';

                $insert_query = "INSERT INTO sanpham(ten, ascii,  gia, discount, km,catid,subcatid, xuatxu, thongso, noibat, mota, CreateDate,hienthi_trangchu,tinhtrang,baohanh,anh,album )
                VALUES('$ten', '$ascii','$gia', '$discount','$khuyenmai', '$catid','$subcatid123', '$xuatxu', '$thongso', $noibat, '$mota', '$CreateDate',$hienthi_trangchu,'$tinhtrang','$baohanh','$filename','$tenfile' )";
                if($sql->query($insert_query)){
                $sql->query($select_insert);
                unset($ten, $mota,$thongso );	
                $HTTP_SESSION_VARS['countadd'] = $HTTP_SESSION_VARS['countadd'] + 1;
                $message 	= "Thông tin về SP thứ ".$HTTP_SESSION_VARS['countadd']." đã được thêm vào CSDL.";							
                }		
                $sql->close();						
        }
      }		
?>
<?php include("lib/header.php")?>
<div id="content">
            <div class="breadcrumb">
            <a href="/">Home</a> :: <a href="index.php?pages=product">Danh mục </a>
             </div>
        <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='warning'>Warning: ".$message1."</div>"; ?>
    <div class="box">
        <div class="heading">
      <h1><img src="images/product.png" alt="" />Thêm một sản phẩm</h1>
            <form action="index.php"  method="post" enctype="multipart/form-data" name="addproduct" id="addproduct">
            <div class="buttons"><input type="submit" value="Thêm" name="submit" class="submit1" >
                <input type="reset" value="Làm lại" name="submit2" class="submit1" > 
            </div>
        </div>
   <div class="content">
     <div id="tab-general">
        <div id="language1">
            <table class="form">
           <?php
            echo ' <tr>
                <td class="tieude">Danh mục sản phẩm  <span class="required">*</span> :</td>
                <td class="text">
                <select style="width:250px; height: 25px" name="catid" id="catid" >
                            <option value="0">-- Chọn danh mục --</option>';
                            for($i=1;$i<=count($cat);$i++){                                                                                                                               
                                         echo '<option value="'.$cat[$i]["catid"].'">'.$cat[$i]["catname"].'</option>';
                             }
                echo '</select>
                <select style="width:200px;height: 25px"  name="subcatid" id="subcatid" disabled="true">
                            <option value="0">--Chọn danh mục con--</option>';                                                                                                                  
                echo ' </select>      

                </td>
                    </tr>';

           ?>
               <tr>
                <td>Hãng SX:<span class="required">*</span> :</td>
                <td>
                  <select name="xuatxu" id="xuatxu" style="width:100px; ">
                    <?php
                        for($i=1; $i<=count($nsx); $i++){
                            if($nsx[$i]["nsxid"] == $nsxid)
                                    echo "<option value=".$nsx[$i]["nsxid"]." selected>".$nsx[$i]["tennsx"]."</option>";
                            else
                                    echo "<option value=".$nsx[$i]["nsxid"].">".$nsx[$i]["tennsx"]."</option>";						
                        }
                     ?>
               </select></td>
              </tr>
              <tr>
                <td>Tên sản phẩm <span class="required">*</span> :</td>
                <td><input type="text" name="ten" size="100" value="<?=$ten?>" />
                  </td>
              </tr>
            <tr>
                <td>Giá sản phẩm <span class="required">*</span> :</td>
                <td><input type="text" name="gia" size="50" value="<?=$gia?>" />
                  </td>
              </tr>                                        
                <tr>
                <td>Giảm Giá (gõ %):</td>
                <td><input type="text" name="discount" size="20" value="<?=$discount?>" /></td>
              </tr>
              <tr>
                <td>Ảnh đại diện sản phẩm <span class="required">*</span> :<br />(Bạn chọn một hình làm ảnh đại diện)</td>
                <td> <input name="anh" type="file" id="anh" value="<?=$anh?>" size="32">
                  </td>
              </tr>  
                <tr>
                <td>Thêm ảnh sản phẩm<span class="required">*</span> : <br />(Bạn có thể lựa chọn nhiều ảnh cho sản phẩm)</td>
                <td> <input name="anhsp[]" type="file" id="anhsp" value="<?=$anhsp?>" size="32" multiple="true">
                  </td>
              </tr>  

               <tr>
              <td>Bảo hành: </td>
              <td><input type="text" name="baohanh" size="50" value="<?=$baohanh?>" /></td>
            </tr>
            <tr>
              <td>Tình trạng: </td>
              <td><input type="text" name="tinhtrang" size="50" value="<?=$tinhtrang?>" /></td>
            </tr>

             <tr>
              <td>Hiển thị trang chủ:</td>
              <td>  <input name="hienthi_trangchu" value="1" checked="checked" type="radio">Đúng
                    <input name="hienthi_trangchu" value="0" type="radio">Sai
                </td>
            </tr>

              <tr>
              <td>Sản phẩm nổi bật:</td>
              <td>  <input name="noibat" value="1" checked="checked" type="radio">Đúng
                    <input name="noibat" value="0" type="radio">Sai
                </td>
            </tr>

             <tr>
                <td>Thông tin khuyến mại:</td>
                <td><textarea  name="khuyenmai" rows="10" cols="80" ><?=$khuyenmai?></textarea></td>
              </tr>

            <tr>
                <td>Mô tả sản phẩm:</td>
                <td><textarea id="elm1" name="mota" rows="20" cols="40" style="width:99%"><?=$mota?></textarea></td>
              </tr>
                <tr>
                <td>Thông số kỹ thuật:</td>
                <td><textarea id="elm2" name="thongso" rows="20" cols="40" style="width:99%"><?=$thongso?></textarea></td>
              </tr>
            </table>
          </div>
     </div>        
      <input name="pages" type="hidden" id="pages" value="product">        
      <input name="mode" type="hidden" id="mode" value="add">        
      </div>
      </form>

  </div>
</div>                          
</div>                         
<?php include("lib/footer.php")?>
</body></html>