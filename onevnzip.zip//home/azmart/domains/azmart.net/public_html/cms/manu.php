<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	if(session_is_registered('countadd'))
            {
		$HTTP_SESSION_VARS['countadd']=0;
            }
	$select_query = "SELECT nsxid, anh, tennsx FROM nsx ORDER BY tennsx";
	$sql->query($select_query);
	$n = $sql->num_rows();				
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
	function delManu(id) {
		if (confirm("Bạn có muốn xóa thật không ?" )) {
			window.location.replace("index.php?pages=manu&mode=del&id=" + id);			
		}
	}
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=manu">Quản lý Nhà sản xuất</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>";?>
      <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Nhà sản xuất (<?=$n?>) </h1>
      <div class="buttons"><a onclick="location = 'index.php?pages=manu&mode=add'" class="button">Thêm</a><a onclick="$('#form').submit();" class="button">Delete</a></div>
    </div>

    <div class="content">
        <? if($n>0){?>
        <table class="list">
          <thead>
            <tr>
              <td class="left">Thứ tự</td>
               <td class="left"></td>
              <td class="left">Têm nhà xuất bản</td>
              <td class="right">Công cụ</td>
            </tr>
          </thead>
          <tbody>
              <?php
                while ($row = $sql->fetch_array()){
                    $from 	= $from + 1;			
                    $nsxid 	= $row['nsxid'];
                    $anh        = $row["anh"] <> "" ? "<img src='".$dir_manufacturers.$row["anh"]."'  style='padding: 1px; border: 1px solid #DDDDDD; width:120px; '>" : 'Chua Anh';
                    $tennsx     = $row['tennsx'];
		?>
            <tr>
              <td class="left"><?= $from ?></td>
              <td class="center"><?= $anh ?></td>
              <td class="left"><?= $tennsx ?> </td>
              <td class="right">[ <a href="index.php?pages=manu&mode=edit&id=<?= $nsxid ?>">Sửa</a> ]
                                [ <a class="openl" onClick="delManu(<?=$nsxid ?>)">Xóa</a> ]
                </td>
            </tr>
            <?php 
            } $sql->close();
            ?>

        </tbody>
        </table>
        <? }else echo "<br><div align=center>Chưa có nhà sản xuất nào trong CSDL !</div>";?>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>