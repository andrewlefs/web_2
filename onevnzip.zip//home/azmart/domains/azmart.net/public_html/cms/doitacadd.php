<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();		
	if($HTTP_POST_VARS[mode] == "add" && isset($HTTP_POST_VARS[mode])){
		if(!session_register('countadd')){
			session_register('countadd');
			$HTTP_SESSION_VARS['countadd']=0;
		}
		$tieude = convert_font($HTTP_POST_VARS["tieude"]);
		$logo 	= isset($_FILES["logo"]["name"]) 		? $_FILES["logo"]["name"] : '';	
		$link 	= convert_font(trim($_POST["link"]));
		$thutu  = isset($_POST['thutu']) ? $_POST["thutu"] : 1;
		//$position  = isset($_POST['position']) ? $_POST["position"] : "left";
		$hienthi  = isset($_POST['hienthi']) ? $_POST["hienthi"] : "1";
		if($logo == "") $message1 = $message1."Bạn chưa chọn logo";
		if($link == "") $message1 = $message1."Hãy nhập liên kết cho logo";
		if($tieude == "") $message1 = $message1."Bạn chưa nhập tiêu đề";
		if ( !empty($logo)){
			$filename = "";
                        $start = strpos($logo,".");
			$type  = substr($logo,$start,strlen($logo));
			if($message1==""){
		    	    	$filename = "logo".time().$type;
	        			if ( !(copy($_FILES['logo']['tmp_name'], $dir_imglogos.$filename)) ) die("Cannot upload file.");
			     }
			
	    }
		$n = $sql->count_rows("doitac") + 1;
		
		if($message1 =="")		
		{			
			$insert_query = "INSERT INTO doitac(logo, link, thutu, tieude, publish) VALUES('$filename', '$link', $thutu, '$tieude', $hienthi)";
			if($sql->query($insert_query))
			{			
				$HTTP_SESSION_VARS['countadd'] = $HTTP_SESSION_VARS['countadd'] + 1;
				$message 	= "Logo thứ ".$HTTP_SESSION_VARS['countadd']." đã được thêm vào CSDL.";			
				unset($logo,$link,$tieude);
			}	
			$n = $sql->count_rows("doitac") + 1;	
			
		}
	}else{
			$sql = new db_sql();
			$sql->db_connect();
			$sql->db_select();
			$n = $sql->count_rows("doitac") + 1;
			
	}
       
?>
<?php include("lib/header.php")?>
<div id="content">
<div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=doitac">Quản lý danh mục đối tác</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='success'>Success: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" /> Danh mục đối tác</h1>
      <form action=index.php method=post enctype="multipart/form-data" name="cateadd" id="cateadd">
      <div class="buttons"><input type="submit" value="Thêm" name="submit" class="submit1" ><a onclick="location = ''" class="button">Cancel</a></div>
    </div>
    <div class="content">
       <div id="tab-general">
       <div id="language1">
            <table class="form">
                <tr>
                    <td><span class="required">*</span>Tên logo</td>
                    <td><input type="text" name='tieude' value="<?=$tieude?>" size="100" /></td>
                </tr>
                <tr>
                    <td><span class="required">*</span>Logo</td>
                    <td>
                        <input name="logo" type="file" value="<?=$logo?>" size="32">
                    </td>
                </tr>
                <tr>
                    <td><span class="required">*</span>Link</td>
                    <td>
                        <input name="link" type="text" value="<?=$link?>" size="100" >
                    </td>
                </tr>
            <tr>
              <td>Hiển thị:</td>
              <td><input name="hienthi" type="checkbox" id="hienthi" value="1" checked></td>
            </tr>
            <tr>
              <td>Thứ tự hiển thị:</td>
              <td>  <select name="thutu" size="1" id="thutu">
                       
                                <?php  
                                 for($i=1; $i<=$n; $i++){
                                 ?>
                                        <OPTION value="<?=$i?>"><?=$i?></OPTION>
                                 <?php }
                                 ?>                           
                            
                        <OPTION value="<?=$n+1?>" selected><?=$n+1?></OPTION>
                    </select></td>
            </tr>
            </table>
          </div>
       </div>
        <input type="hidden" value="Add" name="submit">
        <input name="pages" type="hidden" id="pages" value="doitac">
        <input name="mode" type="hidden" id="mode" value="add">
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>

