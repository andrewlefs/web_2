<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	if($HTTP_POST_VARS["mode"] == "add" && isset($HTTP_POST_VARS["mode"]) && $HTTP_POST_VARS["pages"] == "manu"){
		if(!session_register('countadd')){
			session_register('countadd');
			$HTTP_SESSION_VARS['countadd']=0;
		}
		$tennsx     = isset($_POST["tennsx"])          ? $_POST["tennsx"]             : '';
                $anh        = isset($_POST["tennsx"])          ? huu($_POST["tennsx"])        : '';
                $logo       = isset($_FILES["logo"]["name"]) ? $_FILES["logo"]["name"] : '';
                $thutu      = isset($_POST['thutu']) ? $_POST["thutu"] : 1;
		$hienthi    = isset($_POST['hienthi']) ? $_POST["hienthi"] : 1;
		$message1   = $tennsx == "" ? "Hãy nhập tên danh mục nhà sản xuất" : "";
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();		
		$n = $sql->count_rows("nsx");
                //upload anh lên server
                if ( !empty($logo)){
			$filename = "";
                        $start = strpos($logo,".");
			$type  = substr($logo,$start,strlen($logo));
			if ((strtolower($type)!=".gif")&&(strtolower($type)!=".jpg")&&(strtolower($type)!=".png")){
				$message1 = "Tệp ảnh bìa phải có kiểu tệp là .jpg hoặc .gif hoặc .png";             
	        }
			else{
			if($message1==""){
		    	    	$filename = $anh."-".time().$type;
	        			if ( !(copy($_FILES['logo']['tmp_name'], $dir_manufacturers.$filename)) ) die("Cannot upload file.");
			     }
			}
                }
                
		if($message1 ==""){
                    $tennsx = convert_font($HTTP_POST_VARS["tennsx"],2);
                    $insert_query = "INSERT INTO nsx(tennsx, anh, thutu,publish) VALUES('$tennsx', '$filename','$thutu','$hienthi')";			
                    if($sql->query($insert_query))	{
                            $HTTP_SESSION_VARS['countadd'] = $HTTP_SESSION_VARS['countadd'] + 1;
                            $message = "Th&ocirc;ng tin v&#7873; danh mục nhà sản xuất th&#7913; ".$HTTP_SESSION_VARS['countadd']." &#273;&atilde; &#273;&#432;&#7907;c th&ecirc;m v&agrave;o CSDL";			
                    }		
                    $n = $sql->count_rows("nsx");										
                    $sql->close();	
		}
	}	
	else{
			$sql = new db_sql();
			$sql->db_connect();
			$sql->db_select();
			$n = $sql->count_rows("nsx");
			$sql->close();
	}
?>
<?php include("lib/header.php")?>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=manu">Quản lý Nhà sản xuất</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Warning: ".$message."</div>"; if($message1!="") echo "<div class='warning'>Success: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Nhà sản xuất</h1>
      
      <form action=index.php method=post enctype="multipart/form-data" id="Add" name="Add">
      <div class="buttons"><input type="submit" value="Thêm" name="submit" class="submit1" ><a onclick="location = ''" class="button">Cancel</a></div>
    </div>
    <div class="content">
      <div id="tab-general">
         <div id="language1">
            <table class="form">
              <tr>
                <td><span class="required">*</span> Tên Nhà sản xuất:</td>
                <td><input type="text" name="tennsx" size="100" id="tennsx" value="<?=$tennsx?>" />
                  </td>
              </tr>
              <tr>
                    <td><span class="required">*</span>Logo</td>
                    <td>
                        <input name="logo" type="file" class="input_b2" id="logo" value="<?=$logo?>" size="32">
                    </td>
                </tr>
              <tr>
              <td>Hiển thị:</td>
              <td><input name="hienthi" type="checkbox" id="hienthi" value="1" checked></td>
            </tr>
            <tr>
              <td>Thứ tự hiển thị:</td>
              <td>  <select name="thutu" size="1" id="thutu">
                       
                                <?php  
                                 for($i=1; $i<=$n; $i++){
                                 ?>
                                        <OPTION value="<?=$i?>"><?=$i?></OPTION>
                                 <?php }
                                 ?>                           
                            
                        <OPTION value="<?=$n+1?>" selected><?=$n+1?></OPTION>
                    </select></td>
            </tr>
            
            </table>
          </div>
       </div>
        <input type="hidden" value="Add" name="submit">
        <input name="pages" type="hidden" id="pages" value="manu">
        <input name="mode" type="hidden" id="mode" value="add">
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>
