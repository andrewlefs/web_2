<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();		
	$module_name = 'Trang ngoài';
	$position_page = isset($_GET["position_page"]) && is_numeric($_GET["position_page"])  ? $HTTP_GET_VARS["position_page"]:1;
	$position_page = isset($_POST["position_page"]) ? $_POST["position_page"] : $position_page; 
	$from = $position_page ==1 ? 0 : (($download_per_pagead*$position_page)- $download_per_pagead);
	$count_rows = $sql->count_rows("intro");
	$pages_number = ceil($count_rows/$download_per_pagead);
	
	if(session_is_registered('countadd'))
	{
		$HTTP_SESSION_VARS['countadd']=0;
	}
	//Hien thi thong tin tinh/thanh
	$select_query = "SELECT * FROM intro ORDER BY list_order LIMIT $from, $download_per_pagead";
	$sql->query($select_query);
	$n = $sql->num_rows();					
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
	function delCate(id) {
		if (confirm("Bạn chắc chắn xoá" )) {
			window.location.replace("index.php?pages=<?= $pages ?>&mode=del&id=" + id);			
		}
	}
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=<?= $pages ?>"><?= $module_name ?></a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>";?>
      <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" /><?= $module_name ?> (<?=$n?>) </h1>
      <div class="buttons"><a onclick="location = 'index.php?pages=<?= $pages ?>&mode=add'" class="button">Thêm</a></div>
    </div>

    <div class="content">
       <? if($n>0){?>
        <table class="list">
          <thead>
            <tr>
              <td class="tt">#</td>
              <td class="left">Tiêu đề trên Menu</td>
              <td class="left">Tiêu đề</td>
              <td class="left">Cập nhật</td>
              <td class="left">Giới thiệu</td>
              <td class="left">Publish</td>
              <td class="right">Công cụ</td>
            </tr>
          </thead>
          <tbody>
             <?php
                for($i=1; $i<$n+1; $i++)
		{
			$from   = $from + 1;		
			$row    = $sql->fetch_array();
			$Id     = $row['id'];
			$menu_1 =$row['menu_title'];
                        $Gioithieu =$row['Gioithieu'];
                        $tieude =$row['title'];
                        $User   =$row['UserId'];
                        $change    = $rows['publish']==0?1:0;
			$publish = $row['publish'];
		?>
            <tr>
              <td class="tt"><?= $Id ?></td>
              <td class="left"><?=$menu_1 ?></td>
              <td class="left"><?=$tieude ?></td>
              <td class="left"><?=$User ?></td>
              <td class="left"><?=$Gioithieu==1?"Có":"Không"?></td>
              <td class="left"><?= ($publish == 1 ? '<a style="CURSOR: hand" href="index.php?pages=intro&mode=del&amp;act=upd&s='.$change.'&id='.$Id.'"><img src="images/publish.png" alt="Publish" /></a>' : '<a style="CURSOR: hand" href="index.php?pages=intro&mode=del&amp;act=upd&s='.$change.'&id='.$Id.'"><img src="images/unpublish.png" alt="Publish" /></a>') ?></td>
              <td class="right">[ <a style="CURSOR: hand" href="index.php?pages=<?= $pages ?>&mode=edit&id=<?=$Id ?>">Sửa</a> ]
                                [ <a style="CURSOR: hand" onClick="delCate(<?=$Id ?>)">Xóa</a> ]
                </td>
            </tr>
            <?php 
            } 
            ?>

        </tbody>
        </table>
        <? }else echo "<br><div align=center>Chưa có '.$module_name.' nào trong CSDL !</div>";?>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>