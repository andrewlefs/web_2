<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();
	$newscat = array();
	//get info of news category
	$select_query = "SELECT id, title FROM newscat WHERE publish=1 ORDER BY list_order, title";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$i = $i + 1;
		$newscat[$i]["id"] 	= $rows["id"];
		$newscat[$i]["title"] 	= $rows["title"];	
	}
	//lay  mang chu de sach
	if($HTTP_GET_VARS[mode] == "edit" && $HTTP_GET_VARS['pages']=="new"){
		$idcu = $HTTP_GET_VARS["id"];
		$select_query = "SELECT tieude, trichdan, nguontin, anhtin, ngaydang, frontpage FROM tintuc WHERE tinid = '$id'";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$tieude 	= convert_font($row["tieude"]);
		$trichdan	= convert_font($row["trichdan"],2);
		$nguontin 	= convert_font($row["nguontin"]);
		$tags 		= convert_font($row["tags"],2);
		$frontpage 	= $row['frontpage'];
		$anhcu 		= $row["anhtin"] <> "" ? "<img src='".$dir_imgnews.$row["anhtin"]."'  style='border: 1px solid #000000; padding-left: 0; padding-right: 0; padding-top: 0px; padding-bottom: 0px'>" : 'Tin này chưa có ảnh'; 	
		$imgtemp 	= $row["anhtin"];
		$newscat_id	= $row["newscat_id"];
		$position_page = $_GET["position_page"];
	}	
	
	if($HTTP_POST_VARS[mode] == "edit" && $HTTP_POST_VARS[pages]=="new"){

		$idsua 		= $_POST["id"];		
		$tieude 	= isset($_POST["tieude"])			? convert_font($_POST["tieude"])		: '';
		$tieudeanh 	= isset($_POST["tieude"])			? cut_space(catdau_admin($_POST["tieude"]))		: '';
		$trichdan	= isset($_POST["trichdan"])			? convert_font($_POST["trichdan"])		: '';		
		$nguontin 	= isset($_POST["nguontin"])			? convert_font($_POST["nguontin"])		: '';	
			
		$anhtin 	= isset($_FILES["anhtin"]["name"]) 		? $_FILES["anhtin"]["name"]				: '';
		$frontpage 	= isset($_POST["frontpage"])			? $_POST["frontpage"]					: '0';
		$anhcu 		= $_POST["anhcu"] <> "" 			? stripslashes($_POST["anhcu"]) : '';
		$imgtemp 	= $_POST["imgtemp"];
		
		$position_page = $_POST["position_page"];
				
		if($tieude 		== "") $message1 = $message1."Hãy nhập tiêu đề tin";		
	
	
		//bat dau thuc hien upload anh bia len thu muc tren may chu WEB		
		if ( !empty($anhtin)){
			$filename = "";
	       	$start = strpos($anhtin,".");
			$type  = substr($anhtin,$start,strlen($anhtin));
			if ((strtolower($type)!=".gif")&&(strtolower($type)!=".jpg")){
				$message1 = "<li/>Tệp ảnh bìa phải có kiểu tệp là .jpg hoặc .gif";             
	        }
			else{
				if($message1==""){
		    	    	$filename = time().$type;
	        			if (!copy($_FILES['anhtin']['tmp_name'], $dir_imgnews."origin/".$filename)) die ("Cannot upload file.");
                                                                                                            thumb($_FILES['anhtin']['tmp_name'], $dir_imgnews.$filename, $ratio_image_width, $ratio_image_width, false);
                                                                                                            $file_path = $dir_imgnews.$imgtemp;
                                                                                                            if($imgtemp!="" && file_exists($file_path))	unlink("$file_path");						
                                                                                                              $file_path = $dir_imgnews.'origin/'.$imgtemp;
                                                                                                            if($imgtemp!="" && file_exists($file_path))	unlink("$file_path");	
			     }
			}	
		}
		else{
			if(empty($anhtin)) $filename=$imgtemp;
		}   
		//Bat dau chen DL vao CSDL		
		if($message1 ==""){			
			$tieude 	= convert_font($_POST["tieude"],2);
			$nguontin 	= convert_font($_POST["nguontin"],2);
			$trichdan 	= convert_font($_POST["trichdan"],2);						
			$update_query = "UPDATE tintuc SET tieude='$tieude', trichdan='$trichdan', nguontin='$nguontin', anhtin='$filename', frontpage='$frontpage'  WHERE tinid='$idsua'";
		
			if($sql->query($update_query)){
				$sql->close();
				$message = $message."Cập nhật thành công !";
				include_once("new.php");
				exit();
			}
		}
	}			
?>
<?php include("lib/header.php")?>
<script language="javascript">
function validateForm(){
	if (document.getElementById("newscat_id").value > 0)
		return true;
	else
	{
		alert("Xin hãy chọn một Nhóm tin");
		return false;
	}
}
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=new">Category</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='warning'>Warning: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Sửa nội dung bài viết</h1>
      <form action="index.php?pages=new" method="post" enctype="multipart/form-data" name="edit" id="edit">
      <div class="buttons"><input type="submit" value="Lưu" name="submit" class="submit1" ><input name="Reset" type="reset" class="submit1" value="Reset"></div>
    </div>
    <div class="content">
        <div id="tab-general">
          <div id="language1">
            <table class="form">

              <tr>
                <td><span class="required">*</span>Ti&ecirc;u &#273;&#7873; tin:</td>
                <td><input type="text" name="tieude" size="100" id="tieude" value="<?=$tieude?>" />
                  </td>
              </tr>
              <tr>
                <td><span class="required">*</span>Ảnh cũ:</td>
                <td><?=$anhcu?></td>
              </tr>
              <tr>
                <td><span class="required">*</span>Ảnh minh họa:</td>
                <td><input name="anhtin" type="file" class="input_b2" id="anhtin" value="<?=$anhtin?>" size="32">
                  </td>
              </tr>
               <tr>
                <td><span class="required">*</span>Trích dẫn:</td>
                <td><textarea id="elm2" name="trichdan" rows="20" cols="40" style="width:99%"><?=$trichdan?></textarea>
                  </td>
              </tr>

              <tr>
                <td><span class="required">*</span>Nguồn tin:</td>
                <td><input type="text" name="nguontin" size="100" id="nguontin" value="<?=$nguontin?>" />
                  </td>
              </tr>
              
              <tr>
                <td><span class="required">*</span>Status:</td>
                <td>
                    <select name="frontpage" size=1 id="frontpage">
                        <option value="1"<? echo ($frontpage==1?"selected":"") ?>>Enable</option>
                        <option value="0"<? echo ($frontpage==0?"selected":"") ?>>Disable</option>
                    </select>
                  </td>
              </tr>
            </table>
          </div>
       </div>
        <input name="pages" type="hidden" id="pages" value="new">
        <input name="mode" type="hidden" id="mode" value="edit">       
        <input name="anhcu" type="hidden" id="mode3" value="<?=$anhcu?>">
        <input name="imgtemp" type="hidden" id="mode3" value="<?=$imgtemp?>">
        <input name="position_page" type="hidden" id="tinid_old" value="<?=$position_page?>">
        <input name="id" type="hidden" id="id" value="<?=$idcu?>">
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>
