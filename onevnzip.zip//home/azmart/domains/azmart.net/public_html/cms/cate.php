<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	if(session_is_registered('countadd'))
	{
		$HTTP_SESSION_VARS['countadd']=0;
	}
	//Hien thi thong tin ve chu de sach
	$select_query = "SELECT catid, acce, catname FROM cat ORDER BY thutu, catname";
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	$sql->query($select_query);
	$n = $sql->num_rows();	
	$sql->close();
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
    function delCate(id) {
		if (confirm("Bạn có muốn xóa thật không ? Nếu bạn xóa danh mục này thì tất cả sản phẩm thuộc danh mục cũng bị xóa theo." )) {
			window.location.replace("index.php?pages=cate&mode=del&id=" + id);			
		}
	}
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=cate">Quản lý danh mục </a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>";?>
      <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Danh mục sản phẩm (<?=$n?>) </h1>
      <div class="buttons"><a onclick="location = 'index.php?pages=cate&mode=add'" class="button">Thêm</a><a class="button">Delete</a></div>
    </div>

    <div class="content">
        <? if($n>0){?>
        <table class="list">
          <thead>
            <tr>
              <td width="1" style="text-align: center;"><input type="checkbox" onclick="$('input[name*=\'selected\']').attr('checked', this.checked);" /></td>
              <td class="left">Thứ tự</td>
              <td class="left">T&ecirc;n danh mục sản phẩm</td>
              <td class="right">Công cụ</td>
            </tr>
          </thead>
          <tbody>
              <?php
                for($i=1; $i<=count($cat); $i++){
			$tt = $tt + 1;
			$catid 		= $cat[$i]['catid'];
			$catname 	= $cat[$i]['catname'];
		?>
            <tr>
              <td style="text-align: center;"><input type="checkbox" name="selected[]" value="20" />
                </td>
              <td class="left"><?= $tt ?></td>
              <td class="left"><?=$catname ?> </td>

              <td class="right">[ <a href="index.php?pages=cate&mode=edit&id=<?=$catid ?>">Sửa</a> ]
                                [ <a class="openl" onClick="delCate(<?=$catid ?>)">Xóa</a> ]
                </td>
            </tr>
            	<?php 
		} 
		?>

        </tbody>
        </table>
        <? }else echo "<br><div align=center>Chưa có nhà sản xuất nào trong CSDL !</div>";?>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>
