<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$cat        = array();
        $dm_nsx     = array();
        $dm_price   = array();
        $subcat     = array();
        $hoadon     = array();
	$sql_menu   = new db_sql();
	$sql_menu->db_connect();
	$sql_menu->db_select();
        $count_product     = $sql_menu->count_rows("sanpham");
        $count_cat         = $sql_menu->count_rows("cat");
	$menu_select_query = "SELECT catid,catname, anh FROM cat where hienthi=1 ORDER BY thutu, catname";
	$sql_menu->query($menu_select_query);
	$i = 0;
	while($rows = $sql_menu->fetch_array()){
		$i = $i + 1;
		$cat[$i]["catid"]   = $rows["catid"];		
		$cat[$i]["catname"] = $rows["catname"];
                $cat[$i]["anh"]     = $rows["anh"];
	}
        $catin        = array();
        $menu_select_query = "SELECT Id, Name, UserId FROM IntroCat where Publish=1";
	$sql_menu->query($menu_select_query);
	$i = 0;
	while($rows = $sql_menu->fetch_array()){
		$i = $i + 1;
		$catin[$i]["Id"]   = $rows["Id"];		
		$catin[$i]["Name"] = $rows["Name"];
                $catin[$i]["UserId"] = $rows["UserId"];
	}
        
        $menu_select_query = "SELECT nsxid,tennsx FROM nsx where publish=1 ORDER BY thutu, tennsx";
	$sql_menu->query($menu_select_query);
	$i = 0;
	while($rows = $sql_menu->fetch_array()){
		$i = $i + 1;
		$dm_nsx[$i]["nsxid"]    = $rows["nsxid"];		
		$dm_nsx[$i]["tennsx"]   = $rows["tennsx"];
	}
        
        $menu_select_query = "SELECT id,name FROM khoanggia order by id,name desc";
	$sql_menu->query($menu_select_query);
	$i = 0;
	while($rows = $sql_menu->fetch_array()){
		$i = $i + 1;
		$dm_price[$i]["id"] 	= $rows["id"];		
		$dm_price[$i]["name"] = $rows["name"];
	}
        
        $menu_select_query = "SELECT subcatid,subcatname,catid FROM subcat ORDER BY subcatname";
	$sql_menu->query($menu_select_query);
	$i = 0;
	while($rows = $sql_menu->fetch_array()){
		$i = $i + 1;
		$subcat[$i]["subcatid"] 	= $rows["subcatid"];		
		$subcat[$i]["subcatname"] = $rows["subcatname"];
                                                    $subcat[$i]["catid"] = $rows["catid"];
	}
	
	$newscat = array();
	$menu_select_query = "SELECT id, title, publish FROM newscat ORDER BY list_order, title";
	$sql_menu->query($menu_select_query);
	$i = 0;
	while($rows = $sql_menu->fetch_array()){
		$i = $i + 1;
		$newscat[$i]["id"] 	= $rows["id"];		
		$newscat[$i]["title"] = $rows["title"];
		$newscat[$i]["publish"] = $rows["publish"];
	}
        
                            $menu_select_query = "SELECT id, sanpham_id, sanpham_soluong,noi_dung,ky_danh FROM hoa_don ORDER BY id";
                            $sql_menu->query($menu_select_query);
                            $i = 0;
                            while($rows = $sql_menu->fetch_array()){
                                    $i = $i + 1;
                                    $hoadon[$i]["id"] 	= $rows["id"];		
                                    $hoadon[$i]["sanpham_id"] = $rows["sanpham_id"];
                                    $hoadon[$i]["sanpham_soluong"] = $rows["sanpham_soluong"];
                                    $hoadon[$i]["noi_dung"] = $rows["noi_dung"];
                                    $hoadon[$i]["ky_danh"] = $rows["ky_danh"];
                            }
	
	$sql_menu->close();	
	
	function get_catname($catid){
		global $catname, $cat;
		for($i=1; $i<=count($cat); $i++){
			if($cat[$i]["catid"]==$catid){
				$catname = $cat[$i]["catname"];
				break;
			}				
		}
	return $catname;
	}
        
        function get_intro($intro_catid){
            $intro_subcat = array();
            $sql_menu   = new db_sql();
            $sql_menu->db_connect();
            $sql_menu->db_select();
            $menu_select_query = "SELECT subcatid,subcatname FROM subcat where catid=$intro_catid ORDER BY subcatname";
            $sql_menu->query($menu_select_query);
            $i = 0;
            while($rows = $sql_menu->fetch_array()){
                    $i = $i + 1;
                    $intro_subcat[$i]["subcatid"] 	= $rows["subcatid"];		
                    $intro_subcat[$i]["subcatname"] = $rows["subcatname"];
            }
            return $intro_subcat;
        }
        
       function get_intro_fullname($user){
            global $intro_member;
             $sql_menu   = new db_sql();
            $sql_menu->db_connect();
            $sql_menu->db_select();
            $menu_select_query = "SELECT fullname FROM member where memberid='$user' limit 1";
            $sql_menu->query($menu_select_query);
            $row = $sql_menu->fetch_array();
            $intro_member = $row["fullname"];
            return $intro_member;
        }
     
         function get_intro_email($user){
            global $intro_member;
             $sql_menu   = new db_sql();
            $sql_menu->db_connect();
            $sql_menu->db_select();
            $menu_select_query = "SELECT email FROM member where memberid='$user' limit 1";
            $sql_menu->query($menu_select_query);
            $row = $sql_menu->fetch_array();
            $intro_member = $row["email"];
            return $intro_member;
        }
            function get_intro_phone($user){
            global $intro_member;
             $sql_menu   = new db_sql();
            $sql_menu->db_connect();
            $sql_menu->db_select();
            $menu_select_query = "SELECT phone FROM member where memberid='$user' limit 1";
            $sql_menu->query($menu_select_query);
            $row = $sql_menu->fetch_array();
            $intro_member = $row["phone"];
            return $intro_member;
        }
          function get_intro_sanpham($idsp){
            $intro_sp = array();
             $sql_menu   = new db_sql();
            $sql_menu->db_connect();
            $sql_menu->db_select();
            $menu_select_query = "SELECT ten,gia,anh,namsx,km,thongso,mota,noibat,moi,subcatid,catid FROM sanpham where SanphamID='$idsp' limit 1";
            $sql_menu->query($menu_select_query);
  
            while($rows = $sql_menu->fetch_array()){  
                    $intro_sp["ten"] 	= $rows["ten"];		
                    $intro_sp["gia"] = $rows["gia"];
                    $intro_sp["anh"] = $rows["anh"];
                    $intro_sp["namsx"] = $rows["namsx"];
                    $intro_sp["km"] = $rows["km"];
                    $intro_sp["thongso"] = $rows["thongso"];
                    $intro_sp["mota"] = $rows["mota"];
                    $intro_sp["noibat"] = $rows["noibat"];
                    $intro_sp["moi"] = $rows["moi"];
                    $intro_sp["subcatid"] = $rows["subcatid"];
                    $intro_sp["catid"] = $rows["catid"];
            }
            return $intro_sp;
        }
?>