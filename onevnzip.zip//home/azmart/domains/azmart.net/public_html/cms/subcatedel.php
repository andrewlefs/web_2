<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	
	if ($HTTP_GET_VARS["mode"]=="del" && $HTTP_GET_VARS["pages"]=="subcate" )
	{
		$anhsp = array();
		$id = $_GET["id"];
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
				
		//Count product of cat		
		$select_query = "SELECT anh FROM sanpham WHERE subcatid = $id";
		$sql->query($select_query);
		while($row = $sql->fetch_array()){
			$i=$i+1;
			$anhsp[$i]["anh"] = $row["anh"];
		}
		$n = $sql->num_rows();
		
		if($n>0){		
			$delete_query = "DELETE FROM sanpham WHERE subcatid = $id";
			$sql->query($delete_query);			
			for($i=1; $i<=count($anhsp);$i++){	
				$anh = $anhsp[$i]["anh"];		
				if(!empty($anh)){
					$file_path = $dir_imgproducts.$anh;
					if(file_exists($file_path))	unlink("$file_path");
					/*$small_file_path = $dir_imgproducts."small_".$anh;
					if(file_exists($small_file_path))	unlink("$small_file_path");*/
				}
			}		
			
			$delete_query2 = "DELETE FROM subcat WHERE subcatid = $id";					
			$sql->query($delete_query2);
			$sql->close();
			$message= "Xóa thành công !";
			require_once("subcate.php");
			exit();
		}
		else{			
			$delete_query2 = "DELETE FROM subcat WHERE subcatid = $id";			
			$sql->query($delete_query2);
			$message= "Xóa thành công !";
			require_once("subcate.php");
			exit();
		}					
	}
?>
