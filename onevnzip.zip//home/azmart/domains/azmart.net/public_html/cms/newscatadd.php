<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	if($HTTP_POST_VARS["mode"] == "add" && isset($HTTP_POST_VARS["mode"])){
		if(!session_register('countadd')){
			session_register('countadd');
			$HTTP_SESSION_VARS['countadd']=0;
		}
		$title = convert_font($HTTP_POST_VARS["title"]);
		$publish = $HTTP_POST_VARS["publish"]==1?$HTTP_POST_VARS["publish"]:0;
		$list_order = $HTTP_POST_VARS["list_order"];
		$message1 = $title == "" ? "Hãy nhập tên danh mục nhóm tin" : "";
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();		
		$n = $sql->count_rows("newscat");
		if($message1 ==""){
			$title = convert_font($HTTP_POST_VARS["title"],2);
			$insert_query = "INSERT INTO newscat(title, publish, list_order) VALUES('$title', $publish, $list_order)";			
			if($sql->query($insert_query))	{
				$HTTP_SESSION_VARS['countadd'] = $HTTP_SESSION_VARS['countadd'] + 1;
				$message = "Th&ocirc;ng tin v&#7873; danh mục nhóm tin th&#7913; ".$HTTP_SESSION_VARS['countadd']." &#273;&atilde; &#273;&#432;&#7907;c th&ecirc;m v&agrave;o CSDL";			
			}		
			$n = $sql->count_rows("newscat");										
			$sql->close();	
		}
	}	
	else{
			$sql = new db_sql();
			$sql->db_connect();
			$sql->db_select();
			$n = $sql->count_rows("newscat");
			$sql->close();
	}
?>
<?php include("lib/header.php")?>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=newscat">Category</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='warning'>Warning: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Category</h1>
      
      <FORM action="" method=post enctype="multipart/form-data" name="add" id="add">
      <div class="buttons"><input type="submit" value="Lưu" name="submit" class="submit1" ><a onclick="location = ''" class="button">Cancel</a></div>
    </div>
    <div class="content">
        <div id="tab-general">
          <div id="language1">
            <table class="form">
              <tr>
                <td><span class="required">*</span>Category Name:</td>
                <td><input type="text" name="title" size="100" id="title" value="<?=$title?>" />
                  </td>
              </tr>
             <tr>
                <td><span class="required">*</span>Sort Order:</td>
                <td><SELECT name=list_order size=1 id="list_order">
                             <?php  
                             for($i=1; $i<=$n; $i++){
                             ?>
                                    <OPTION value="<?=$i?>"><?=$i?></OPTION>
                             <?php }
                             ?>
                             <OPTION value="<?=$n+1?>" selected><?=$n+1?></OPTION>
                          </SELECT>
                  </td>
              </tr>
              <tr>
                <td><span class="required">*</span>Status:</td>
                <td><INPUT name=publish type=checkbox id="publish" style="FLOAT: left" value=1 checked>
                  </td>
              </tr>
            </table>
          </div>
       </div>
        <input type="hidden" value="Add" name="submit">
        <input name="pages" type="hidden" id="pages" value="newscat">
        <input name="mode" type="hidden" id="mode" value="add">
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>
