﻿<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	
	if($HTTP_GET_VARS[mode] == "detail")
	{
		$id = $HTTP_GET_VARS["id"];
		$select_query = "SELECT ten, catid, subcatid, nsxid, gia, currencyid, namsx, kho, baohanh, anh, moi, noibat, mota, thongso 
						FROM sanpham WHERE sanphamid = '$id'";
						
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$ten 	= $row["ten"]; 	
		$tensach 	= $row["tensach"];	$catid = $row["catid"];	$subcatid = $row["subcatid"];
		$nsxid 		= $row["nsxid"];	$gia 	= $row["gia"]; 		$currencyid 	= $row["currencyid"];
		$namsx 		= $row["namsx"]; 	$kho 		= $row["kho"]; 	$baohanh 		= $row["baohanh"];
		$moi 	= $row["moi"]==1 	? "YES" : "NO";  $noibat 	= $row["noibat"]==1	? "YES" : "NO";
		$mota 	= nl2br($row["mota"]); 	$thongso 	= nl2br($row["thongso"]); 
		$anh 	= $row["anh"] <> "" ? "<img src='".$dir_imgproducts.$row["anh"]."' style='border: 0px solid #000000; padding-left: 0; padding-right: 0; padding-top: 0px; padding-bottom: 0px' onClick=OpenNewWindow('../comm/imagesviewer.php?img=".$dir_imgproducts."origin/".$row["anh"]."&mode=back',500,500)>" : "Chưa có ảnh SP"; 	

		$select_query = "SELECT catname FROM cat WHERE catid = $catid";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$catname = $row["catname"];
		
		if($subcatid<>0){
			$select_query = "SELECT subcatname FROM subcat WHERE subcatid = $subcatid";
			$sql->query($select_query);
			$row = $sql->fetch_array();
			$subcatname = $row["subcatname"];
		}
		
		$select_query = "SELECT tennsx FROM nsx WHERE nsxid = $nsxid";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$tennsx = $row["tennsx"];
		
		$select_query = "SELECT name FROM currency WHERE currencyid = $currencyid";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$currency = $row["name"];			

		$sql->close();
	}
	
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<META content="DEMO - Thuong mai dien tu - Kinh doanh tren Internet - Quang ba san pham..." name=keywords>
<META content="DEMO" name=description>
<LINK href="../style/mstyle.css" rel=stylesheet type=text/css>
<script language='Javascript' src='viettyping.js'></script>
<script language="javascript">
	function OpenNewWindow(url,w,h) {
		window.open(url,'new_page','toolbar=no,location=no,menubar=no,scrollbars=yes,width=' + w + ',height=' + h + ',top=60,left=100,resizeable=no,status=no');
	}
</script>
<title>-- Detail Information of Product --</title>
</head>
<body><div align="center">
<br>
<table width="600" align="center" cellspacing="0">
  <form action="index.php?pages=book&mode=add" method="post" enctype="multipart/form-data" name="addbook" id="addbook">
    <tr>
      <td valign="top" bgcolor="#d4d0c8">
        <table bgcolor="whitesmoke"  width="634" cellpadding="2" cellspacing="1" >
          <tr class="header_table">
            <td colspan="4" valign="top" bgcolor="whitesmoke" class="book_header"> <div align="center">TH&Ocirc;NG TIN CHI TIẾT V&#7872; SẢN PHẨM</div></td>
          </tr>
          <tr class="book_tr">
            <td width="28%"   class="book_tr_left" >Tên sản phẩm:</td>
            <td width="72%"  colspan="3">
              <span class="header_table">
              <?=$ten?>
            </span>            </td>
          </tr>
          <tr class="book_tr">
            <td  class="book_tr_left"  >Hãng sản xuất</td>
            <td  colspan="3">
              <span class="header_table">
              <?=$tennsx?>
              </span></td>
          </tr>
          <tr class="book_tr">
            <td   class="book_tr_left" >Giá sản phẩm</td>
            <td    colspan="3">
              <span class="header_table">
              <?=$gia?>
            </span>            </td>
          </tr>
          <tr class="book_tr">
            <td    class="book_tr_left" >Đơn vị tiền t&#7879;:</td>
            <td    colspan="3">
              <span class="header_table">
              <?=$currency?>
            </span>            </td>
          </tr>
          <tr  class="book_tr">
            <td     class="book_tr_left" >Thuộc danh mục:</td>
            <td    colspan="3">
              <span class="header_table">
              <?=$catname." - ".$subcatname?>
              </span></td>
          </tr>
          <tr class="book_tr">
            <td     class="book_tr_left" >Trạng thái đặt hàng:</td>
            <td     colspan="3">
              <span class="header_table">
              <?=$kho?>
            </span>            </td>
          </tr>
          <tr class="book_tr">
            <td  class="book_text" >Bảo hành:</td>
            <td  colspan="3"><span class="header_table">
              <?=$baohanh?>
            </span></td>
          </tr>
          <tr class="book_tr">
            <td  class="book_text" >Ảnh sản phẩm:</td>
            <td  colspan="3"><?=$anh?></td>
          </tr>
          <tr class="book_tr">
            <td    class="book_tr_left" >Năm sản xuất :</td>
            <td    colspan="3">
              <span class="header_table">
              <?=$namsx?>
              </span></td>
          </tr>
          <tr class="book_tr">
            <td    class="book_tr_left" >Sản phẩm mới: </td>
            <td    colspan="3">
              <span class="header_table">
              <?=$moi?>
              </span></td>
          </tr>
          <tr class="book_tr">
            <td    class="book_tr_left" >Sản phẩm nổi bật:</td>
            <td    colspan="3">
              <span class="header_table">
              <?=$noibat?>
            </span></td>
          </tr>
          <tr  class="book_tr">
            <td  valign="top" class="book_text" >Mô tả sản phẩm:</td>
            <td valign="top"  colspan="3">
              <div align="justify"><span class="header_table">
                <?=$mota?>
              </span> </div></td>
          </tr>
          <tr  class="book_tr">
            <td  valign="top" class="book_text" >Các thông số kỹ thuật:</td>
            <td valign="top"  colspan="3">
              <div align="justify"><span class="header_table">
                <?=$thongso?>
              </span></div></td>
          </tr>
          <tr  class="book_tr">
            <td colspan="4"  valign="top" class="book_text" ><div align="center">
              <p>&nbsp;</p>
              <p><a href="javascript:print()">Print</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:close()">Close</a></p>
            </div></td>
          </tr>
      </table></td>
    </tr>
  </form>
</table>
<br>
	<br>
</div></body>
</html>