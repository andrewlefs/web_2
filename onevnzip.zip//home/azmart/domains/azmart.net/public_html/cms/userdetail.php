﻿<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	if(session_is_registered('countadd'))
	{
		$HTTP_SESSION_VARS['countadd']=0;
	}	
	$select_query = "SELECT tmpname, logon, logout FROM users ORDER BY fullname";
	$sql->query($select_query);	
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<META content="DEMO - Thuong mai dien tu - Kinh doanh tren Internet - Quang ba san pham..." name=keywords>
<META content="DEMO" name=description>
<LINK href="../style/mstyle.css" rel=stylesheet type=text/css>
<script language='Javascript' src='viettyping.js'></script>
<title>-- Manager Users --</title>
<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
</head>
<body><div align="center">
	<table width="780" border="0" align="center" cellpadding="2" cellspacing="0">
	<tbody>
	  <tr>
	    <td width="143" align="center" bgcolor='whitesmoke' class="logout">[ <a href="index.php?pages=logout">Logout</a> ]</td>
	    <td align="center" bgcolor='whitesmoke' class="menu_bar_manager"><?=$detail = $HTTP_SESSION_VARS["super"]==1 ? "[ <a href='index.php?pages=user&mode=add'>Add User</a> ] [ <a href='index.php?pages=user'>Manager User</a> ][ <a href='index.php?pages=user&mode=detail'>History</a> ]" : ''?></td>
      </tr>
	  </tbody>
</table> 
	

      <table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td bgcolor='whitesmoke' width="147" height="100%" valign="top"><?php include("menu.php"); ?></td>
     <td width="633" valign="top">
  </form>
	<center>	<div align="center">	 <br>	  
	<table width="550">
        <tr>
          <td class="header_table"><div align="center">Th&ocirc;ng tin v&#7873; thời gian nh&acirc;n vi&ecirc;n quản tr&#7883; Website cập nhật th&ocirc;ng tin lần cuối</div></td>
        </tr>
      </table>
	  <table borderColor="whitesmoke" cellSpacing="0" cellPadding="2" width="550" align="center" border="1">
        <tr bgColor="whitesmoke">
          <td width="33" align="middle" class="colum_order" > Order</td>
          <td width="201" class="header_table" > Full Name </td>
          <td width="145" class="header_table" >Logon</td>
          <td ><span class="header_table">Logout</span></td>
        </tr>
		<?php
        while ($row = $sql->fetch_array())
		{
			$from 		= $from + 1;			
			$tmpname 	= $row['tmpname'];			
			$logon	 	= $row[logon]!=0 ? gmdate("d/m/Y, h:i, a",$row["logon"] + 7*3600) : '';
			$logout	 	= $row[logout]!=0 ? gmdate("d/m/Y, h:i, a",$row["logout"] + 7*3600) : '';						
		?>
		<tr>
          <td align="middle" class="colum_order" > <?= $from ?></td>
          <td class="header_table" ><?= $tmpname ?></td>
          <td class="header_table" ><?= $logon ?></td>
		  <td width="145" class="header_table" ><?= $logout ?></td>          
        </tr>
		<?php 
		} $sql->close();
		?>
      </table>
	  <br>	  
    </div>   	</td>
    </tr>
</table> 
</div></body>
</html>