<?php
ob_start();
define("qaz_wsxedc_qazxc0FD_123K",true);
$phpbb_root_path = '../config/';
include($phpbb_root_path."mysql.php");
include($phpbb_root_path."config.php");
include($phpbb_root_path."function.php");

$tpid = $_GET["tpId"];


if($tpid==0){
                 echo '<select style="width:200px;height: 25px" name="subcatid" >
                            <option value="0">-- Danh mục sản phẩm con --</option></select>';
}else if($tpid!=0){    
            $sql = new db_sql();
            $sql->db_connect();
            $sql->db_select();           
            $query = "SELECT `subcatid`, `subcatname` FROM `subcat` WHERE `catid` =$tpid";
             $huyen_arr = array();
            $sql->query($query);
            $i=0;
            while($row = $sql->fetch_array())
            {
                  $i=$i+1;
                  $huyen_arr[$i]["id"] = $row["subcatid"];
                  $huyen_arr[$i]["name"] = $row["subcatname"];
            }
            
            if(empty($huyen_arr)){
                        echo '<select style="width:200px;height: 25px" name="subcatid">
                                                 <option value="0">-- Danh mục sản phẩm con --</option>
                                   </select>';
            }else if(!empty ($huyen_arr)){
                        echo '<select style="width:200px;height: 25px" name="subcatid" id="subcatid" >
                                                      <option value="0">-- Danh mục sản phẩm con --</option>';
                                                        for($j=1;$j<=count($huyen_arr);$j++){
                                                             echo '<option value="'.$huyen_arr[$j]["id"].'">'.$huyen_arr[$j]["name"].'</option>';
                                                         }
                          echo '</select>';
                }
}
?>

