<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();		
	//get info of news category
	$select_query = "SELECT id, title FROM newscat WHERE publish=1 ORDER BY list_order, title";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$i = $i + 1;
		$newscat[$i]["id"] 	= $rows["id"];
		$newscat[$i]["title"] 	= $rows["title"];	
	}
	$newscat_id	= isset($_GET["newscat_id"])   ? $_GET["newscat_id"]   : (isset($_POST["newscat_id"])  ? $_POST["newscat_id"]  : "");	
	
	$position_page = isset($_GET["position_page"]) && is_numeric($_GET["position_page"])  ? $HTTP_GET_VARS["position_page"]:1;
	$position_page = isset($_POST["position_page"]) ? $_POST["position_page"] : $position_page; 
	$from = $position_page ==1 ? 0 : (($admin_page*$position_page)- $admin_page);
	$count_rows = $sql->count_rows("tintuc");
	$pages_number = ceil($count_rows/$admin_page);
	
	if(session_is_registered('countadd'))
	{
		$HTTP_SESSION_VARS['countadd']=0;
	}
	//Hien thi thong tin tinh/thanh
	$select_query = "SELECT tinid, tieude, ngaydang, frontpage FROM tintuc ".($newscat_id>0?"WHERE newscat_id = $newscat_id":"")." ORDER BY ngaydang DESC LIMIT $from, $admin_page";
	$sql->query($select_query);
	$n = $sql->num_rows();					
?>
<?php include("lib/header.php")?>
<script language="JavaScript" type="text/javascript">
	function delNew(id, newscat,sn_id,position_page) {
		if (confirm("Bạn có muốn xóa thật không ?" )) {
			window.location.replace("index.php?pages=new&mode=del&act=del&position_page="+position_page+"&newscat="+newscat+"&id=" + id);			
		}
	}
	function open_window(id){
			window.open("index.php?pages=new&mode=detail&id=" +id ,"","width=800,height=600,left=0,top=0,scrollbars=yes");
	}
</script>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=new&newscat=<?=$newscat_id?>">Category</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>";?>
      <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Tin tức</h1>
      <div class="buttons"><a onclick="location = 'index.php?pages=new&mode=add'" class="button">Thêm</a><a onclick="$('#form').submit();" class="button">Delete</a></div>
    </div>

    <div class="content">
        <tr>
          <td class="header_table"><div align="left">
            <form action="index.php?pages=new" method="post"  enctype="multipart/form-data" name="subcate"  id="subcate" style="float:left; margin-right:20px;" >
                <select size="1" name="newscat_id" id="newscat_id" onchange="document.location='index.php?pages=new&newscat_id=' + document.getElementById('newscat_id').value ">
                          <option value="0">All</option>
                          <?php
                          for($i=1;$i<=count($newscat);$i++)
                                if($newscat[$i]["id"] == $newscat_id)
                                        echo "<option value='".$newscat[$i]["id"]."' selected>".$newscat[$i]["title"]."</option>";
                                else
                                        echo "<option value='".$newscat[$i]["id"]."'>".$newscat[$i]["title"]."</option>";
                          ?>
                  </select>
              <input name="newscat_id" type="hidden" id="newscat_id" value="<?=$newscat_id?>">
                </form>
               </div>
	</td>
        </tr>

        <? if($count_rows>0){ ?>
        <table class="list">
          <thead>
            <tr>
              <td class="tt">Order</td>
              <td class="left">T&ecirc;n bản tin</td>
              <td class="left">Date</td>
              <td class="left">Publish</td>
              <td class="right">Công cụ</td>
            </tr>
          </thead>
          <tbody>
             <?php
                for($i=1; $i<$n+1; $i++){
			$from = $from + 1;		
			$row = $sql->fetch_array();
			$tinid = $row['tinid'];
			$tieude =$row['tieude'];
			$change 	= $row['frontpage']==0?1:0;
			$ngaydang = gmdate("d/m/Y, h:i, a",$row["ngaydang"] + 7*3600);
			$frontpage = $row['frontpage'];
			$sn_id = $row['sn_id'];
		?>
            <tr>
              <td class="tt"><?= $from ?></td>
              <td class="left"><a title="Information detail" style="CURSOR: hand" onClick="open_window(<?=$tinid ?>)"><?= $tieude ?></a></td>
              <td class="left"><?= $ngaydang ?></td>
              <td class="left"><?= ($frontpage == 1 ? 'C&#243;' : 'Kh&#244;ng') ?> <a style="CURSOR: hand" href="index.php?pages=new&newscat=<?=$newscat_id?>&mode=del&amp;act=upd&s=<?=$change?>&id=<?=$tinid?>">Change</a></td>
              <td class="right">[ <a style="CURSOR: hand" href="index.php?pages=new&mode=edit&position_page=<?=$position_page?>&id=<?= $tinid ?>">Sửa</a> ]
                                [ <a style="CURSOR: hand" onClick="delNew('<?=$tinid?>','<?=$newscat_id?>','<?=$position_page?>')">Xóa</a> ]
                </td>
            </tr>
            <?php 
		} $sql->close();
		?>

        </tbody>
        </table>
        <?php pages_browser_admin("index.php?pages=new&newscat=".$newscat_id."&position_page=",$position_page,$pages_number);?>
        <? }else echo "<br><div align=center>Chưa có nhà sản xuất nào trong CSDL !</div>";?>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body>
</html>