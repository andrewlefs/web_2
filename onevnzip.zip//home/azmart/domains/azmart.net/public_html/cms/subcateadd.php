<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
            $intro_cat = array();
                  $sql = new db_sql();
               $sql->db_connect();
               $sql->db_select();	
               //get thong tin cat(danh muc cha)
           $select = "select catid,catname from cat where hienthi=1 order by thutu,catname";
           $sql->query($select);
           $i=0;
           while ($rows = $sql->fetch_array()){
               $i=$i+1;
               $intro_cat[$i]["catid"] = $rows["catid"];
               $intro_cat[$i]["catname"] = $rows["catname"];
           }
  
	if($HTTP_POST_VARS["mode"] == "add" && isset($HTTP_POST_VARS["mode"]) && $HTTP_POST_VARS["pages"]=="subcate"){
		if(!session_register('countadd')){
			session_register('countadd');
			$HTTP_SESSION_VARS['countadd']=0;
		}
            
              
		$subcatname = convert_font($HTTP_POST_VARS["subcatname"]);
		$catid = isset($HTTP_POST_VARS["catid"])?$HTTP_POST_VARS["catid"]:0;
		$catid = is_numeric($catid)?$catid:0;
                
		$message1 = $subcatname == "" ? "Hãy nhập tên danh mục sản phẩm con" : "";
			
		$n = $sql->count_rows("subcat") + 1;
		if($message1 ==""){
			$catname = convert_font($HTTP_POST_VARS["subcatname"],2);
			$insert_query = "INSERT INTO subcat(subcatname,catid) VALUES('$catname', $catid)";			
			if($sql->query($insert_query)){	
                            unset($subcatname);
				$HTTP_SESSION_VARS['countadd'] = $HTTP_SESSION_VARS['countadd'] + 1;
				$message = "Th&ocirc;ng tin v&#7873; danh mục sản phẩm th&#7913; ".$HTTP_SESSION_VARS['countadd']." &#273;&atilde; &#273;&#432;&#7907;c th&ecirc;m v&agrave;o CSDL";			
			}		
			$n = $sql->count_rows("subcat") + 1;										
			$sql->close();	
		}
	}	
	else{
			$sql = new db_sql();
			$sql->db_connect();
			$sql->db_select();
			$n = $sql->count_rows("subcat") + 1;
			$sql->close();
	}
?>
<?php include("lib/header.php")?>
<div id="content">
<div class="breadcrumb">
        <a href="/">Home</a>
         :: <a href="index.php?pages=subcate">Quản lý danh mục </a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='success'>Success: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" /> Danh mục sản phẩm</h1>
      <form action=index.php method=post enctype="multipart/form-data" name="subcateadd" id="subcateadd">
      <div class="buttons"><input type="submit" value="Thêm" name="submit" class="submit1" ><a onclick="location = ''" class="button">Cancel</a></div>
    </div>
    <div class="content">
       <div id="tab-general">
       <div id="language1">
            <table class="form">
          
                <tr>
                    <td><span class="required">*</span>Chọn danh mục sản phẩm cha</td>
                    <td>
                        <select name="catid" id="catid">
                            <?php
                                for($i=1;$i<=count($intro_cat);$i++){?>
                            <option value="<?=$intro_cat[$i]['catid']?>"><?php echo $intro_cat[$i]["catname"];?></option>
                                <?}
                            ?>
                        </select>
                    </td>
                </tr>
              <tr>
                <td><span class="required">*</span> Tên danh mục:</td>
                <td><input type="text" name="subcatname" size="100" id="subcatname" value="<?=$subcatname?>" />
                  </td>
              </tr>          
            </table>
          </div>
       </div>
        <input type="hidden" value="Add" name="submit">
        <input name="pages" type="hidden" id="pages" value="subcate">
        <input name="mode" type="hidden" id="mode" value="add">
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>

