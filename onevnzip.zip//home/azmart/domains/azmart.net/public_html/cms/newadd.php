<?php
	if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
        $UserId = $HTTP_SESSION_VARS['user_admin'];
	$ngaydang = time(); 
	$sql = new db_sql();
	$sql->db_connect();	
	$sql->db_select();		
	$newscat = array();
	//get info of news category
	$select_query = "SELECT id, title FROM newscat WHERE publish=1 ORDER BY list_order, title";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$i = $i + 1;
		$newscat[$i]["id"] 	= $rows["id"];
		$newscat[$i]["title"] 	= $rows["title"];	
	}
	if($HTTP_POST_VARS[mode] == "add" && isset($HTTP_POST_VARS[mode])){
		if(!session_register('countadd')){
			session_register('countadd');
			$HTTP_SESSION_VARS['countadd']=0;
		}
		//lay thong tin ve cac danh muc				
		$tieude 	= isset($_POST["tieude"])		? convert_font($_POST["tieude"])	: '';
		$tieudeanh 	= isset($_POST["tieude"])		? cut_space(catdau_admin($_POST["tieude"]))		: '';
		$trichdan 	= isset($_POST["trichdan"])		? convert_font($_POST["trichdan"])	: '';;			
		$nguontin 	= isset($_POST["nguontin"])		? convert_font($_POST["nguontin"])	: '';;			
		$tags 		= isset($_POST["tags"])			? convert_font($_POST["tags"])		: '';		
		$anhtin 	= isset($_FILES["anhtin"]["name"]) 	? $_FILES["anhtin"]["name"]		: '';		
		//$newscat_id	= $_POST["newscat_id"];
		
		if($tieude 	== "") $message1 = $message1."Hãy nhập tiêu đề tin";		
		//if($newscat_id 	== 0) $message1 = $message1."Hãy chọn một nhóm tin";
	
		//bat dau thuc hien upload anh bia len thu muc tren may chu WEB		
		if ( !empty($anhtin)){
			$filename = "";
	       	$start = strpos($anhtin,".");
			$type  = substr($anhtin,$start,strlen($anhtin));
			if ((strtolower($type)!=".gif")&&(strtolower($type)!=".jpg")){
				$message1 = "Tệp ảnh bìa phải có kiểu tệp là .jpg hoặc .gif";             
	        }
			else{
			if($message1==""){
		    	    	$filename = time().$type;
	        			if (!copy($_FILES['anhtin']['tmp_name'], $dir_imgnews."origin/".$filename)) die ("Cannot upload file.");
						thumb($_FILES['anhtin']['tmp_name'], $dir_imgnews.$filename, $ratio_image_width, $ratio_image_width, false);
			     }
			}
	    }
		//Bat dau chen DL vao CSDL		
		if($message1 == ""){			
			$tieude 	= isset($_POST["tieude"])				? convert_font($_POST["tieude"],2)		: '';
			
			$trichdan 	= isset($_POST["trichdan"])				? convert_font($_POST["trichdan"],2)		: '';
			$nguontin 	= isset($_POST["nguontin"])				? convert_font($_POST["nguontin"],2)	: '';;			
			$tags 	= isset($_POST["tags"])						? convert_font($_POST["tags"],2)		: '';
			$frontpage 	= isset($_POST["frontpage"])			? $_POST["frontpage"]					: '0';
			$insert_query = "INSERT INTO tintuc(tieude, trichdan, nguontin, anhtin, ngaydang, frontpage) ";
			$insert_query = $insert_query." VALUES('$tieude',  '$trichdan', '$nguontin', '$filename', '$ngaydang', $frontpage)";
			if($sql->query($insert_query)){			
				unset($tieude, $nguontin, $trichdan );				
				$message = "Cập nhật thành công .";							
			}		
			$sql->close();						
		}
	}		
?>
<?php include("lib/header.php")?>
<div id="content">
  <div class="breadcrumb">
        <a href="/">Home</a>:: <a href="index.php?pages=new">Category</a>
     </div>
    <?php if($message!="") echo "<div class='success'>Success: ".$message."</div>"; if($message1!="") echo "<div class='warning'>Warning: ".$message1."</div>"; ?>
    <div class="box">
    <div class="heading">
      <h1><img src="images/category.png" alt="" />Th&ecirc;m một bài viết</h1>
      
      <form action="index.php?pages=new&mode=add" method="post" enctype="multipart/form-data" name="add" id="add">
      <div class="buttons"><input type="submit" value="Lưu" name="submit" class="submit1" ><input name="Reset" type="reset" class="submit1" value="Reset"></div>
    </div>
    <div class="content">
        <div id="tab-general">
          <div id="language1">
            <table class="form">
<!--                <tr>
                <td><span class="required">*</span>Sub Danh mục tin:</td>
                <td><select name="newscat_id" >
                          <option value="0"> -- Chọn một danh mục -- </option>
				  <?php
				  for($i=1;$i<=count($newscat);$i++)
                                        echo "<option value='".$newscat[$i]["id"]."'>".$newscat[$i]["title"]."</option>";
				  ?>
		</select> 
                  </td>
              </tr>-->
              <tr>
                <td><span class="required">*</span>Ti&ecirc;u &#273;&#7873; tin:</td>
                <td><input type="text" name="tieude" size="100" id="tieude" value="<?=$tieude?>" />
                  </td>
              </tr>
              <tr>
                <td><span class="required">*</span>Ảnh minh họa:</td>
                <td><input name="anhtin" type="file" class="input_b2" id="anhtin" value="<?=$anhbia?>" size="32">
                  </td>
              </tr>
               <tr>
                <td><span class="required">*</span>Trích dẫn:</td>
                <td><textarea id="elm2" name="trichdan" rows="20" cols="40" style="width:99%"><?=$trichdan?></textarea>
                  </td>
              </tr>
<!--              <tr>
                <td><span class="required">*</span>Tags:</td>
                <td><input type="text" name="tags" size="100" value="<?=$tags?>" />
                  </td>
              </tr>-->
              <tr>
                <td><span class="required">*</span>Nguồn tin:</td>
                <td><input type="text" name="nguontin" size="40" value="<?=$nguontin?>" />
                  </td>
              </tr>
              
              <tr>
                <td><span class="required">*</span>Status:</td>
                <td><select name="frontpage">
                            <option value="0" selected="selected">Disabled</option>
                            <option value="1">Enabled</option>
                    </select>
                </td>
              </tr>
            </table>
          </div>
       </div>
        <input name="pages" type="hidden" id="pages" value="new">        
        <input name="mode" type="hidden" id="mode" value="add">	
      </form>
    </div>
  </div>
</div>
</div>
<?php include("lib/footer.php")?>
</body></html>
