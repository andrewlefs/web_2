$.addToCard = function(id) {
	$.ajax({
		url: baseUrl + "gio-hang-ajax/"+id+".htm",
		success: function( data ) {
			if(data == 'add')
		    {	
		    	var totalProduct = parseInt($('.totalProduct').text());
		    	totalProduct += 1;
		    	$('.totalProduct').text(totalProduct);
		    }
		    alert('San pham da duoc them vao gio hang thanh cong');
		}
	});
}