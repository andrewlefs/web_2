$(document).ready(function() {
	 $('#slide').coinslider({
		 
		width:979, // width of slider panel
		height: 271, // height of slider panel
		spw: 7, // squares per width
		sph: 5, // squares per height
		delay: 3000, // delay between images in ms
		sDelay: 30, // delay beetwen squares in ms
		opacity: 0.7, // opacity of title and navigation
		titleSpeed: 500, // speed of title appereance in ms
		effect: 'swirl', // random, swirl, rain, straight
		navigation: true, // prev next and buttons
		links : true, // show images as links
		hoverPause: true // pause on hover
		 });
	//////////////////////////
			$(function() {
				var _visible = 4;
				var $pagers = $('#pager a');
				var _onBefore = function() {
					$(this).find('img').stop().fadeTo( 300, 1 );
					$pagers.removeClass( 'selected' );
				};

				$('#carousel').carouFredSel({
					items: _visible,
					width: '1000',
					auto:false,
					scroll: {
						duration: 979
					},
					prev: {
						button: '#prev',
						items: 1,
						onBefore: _onBefore
					},
					next: {
						button: '#next',
						items: 1,
						onBefore: _onBefore
					},
				});

				$pagers.click(function( e ) {
					e.preventDefault();
					
					var group = $(this).attr( 'href' ).slice( 1 );
					var slides = $('#carousel li.' + group);
					var deviation = Math.floor( ( _visible - slides.length ) / 2 );
					if ( deviation < 0 ) {
						deviation = 0;
					}

					$('#carousel').trigger( 'slideTo', [ $('#' + group), -deviation ] );
					$('#carousel li img').stop().fadeTo( 300, 0.3 );
					slides.find('img').stop().fadeTo( 300, 1 );

					$(this).addClass( 'selected' );
				});
				

//tap--------------------------
		$(".tab_content:not(:first)").hide(); // Ẩn toàn bộ nội dung của tab
		$(".tab_container ul li:first").addClass("active")
		$(".tab_container ul li ").click(function(){ //Khai báo sự kiện khi click vào một tab nào đó
                var activeTab = $(this).children('a').attr("alt"); 
                $(".tab_container ul li ").removeClass("active"); 
                $(this).addClass("active"); 
                $(".tab_content").hide(500); 
                $(activeTab).slideDown(500) 
		});			
			});
//tap--------------------------
		$(".tabContents1").hide(); // áº¨n toÃ n bá»™ ná»™i dung cá»§a tab
		$(".tabContents1:first").show(); // Máº·c Ä‘á»‹nh sáº½ hiá»ƒn thá»‹ tab1
		$("#tabContaier1 ul li a").click(function(){ //Khai bÃ¡o sá»± kiá»‡n khi click vÃ o má»™t tab nÃ o Ä‘Ã³
                    var activeTab = $(this).attr("alt"); 
                    $("#tabContaier1 ul li a").removeClass("active"); 
                    $(this).addClass("active"); 
                    $(".tabContents1").hide(); 
                    $(activeTab).fadeIn(); 
		});
//////////
$(function(){
 var uynh_content_h=$(".support_online .content").height();
 $(".support_online").css("bottom",-uynh_content_h+"px");
 $(".support_online .title").toggle(function(){
      $(this).addClass("active");
   $(this).closest(".support_online").animate({bottom:0},400)
  },function(){
    $(this).removeClass("active");
   $(this).closest(".support_online").animate({bottom:-uynh_content_h},400)
   })
 })
    /////////////////////////
$('.nav_menu li').hover(function(){
	  $(this).children('ul:first').stop(true,true).slideDown(200)
	  },function(){
		  $(this).children('ul:first').slideUp(200)
		  });
//////////
//////////
$('.danhmuc li').hover(function(){
	  $(this).children('ul:first').stop(true,true).slideDown(200)
	  },function(){
		  $(this).children('ul:first').slideUp(200)
		  });
//////////
$(".top_main .danhmuc").hover(function(){
	  $(".top_main .danhmuc").find(".content").stop(true,true).slideDown(200)
	  },function(){
		 	  $(".top_main .danhmuc").find(".content").slideUp(200)

		  });
/////////////////////////
$(function(){
	$('.nav_menu li ul').closest('li').addClass('have_children')})	
/////////////////////////
$(function(){
	$('.nav_menu li ul ul').closest('li').addClass('have_children11')})	
	
	
$(function(){
	$('.danhmuc li ul').closest('li').addClass('have_children1')})
	
	
//////////////////////////////////
$(function(){
	$('.danhmuc li ul ul').closest('li').addClass('have_children2')})	

//////////
$(".style_sp li").hover(function(){
	$(this).find(".hide").stop(true,true).animate({bottom:50,opacity:1},400)
	},function(){
		$(this).find(".hide").animate({bottom:-120,opacity:0},300)
		})
		


	
		$("#slidesp li img	").hover(function(){
	$(this).stop(true,true).animate({opacity:0.5},300)
	},function(){
		$(this).animate({opacity:1},300)
		})
////////////////////////
active_slide('.slide_view')
/////////////////////////////////////
$('.dm li').click(function(){
	$('.dm li').find('ul').slideUp(300)
				if (!$(this).hasClass('active')) {
				  $('.dm li').removeClass('active');
				  $(this).addClass('active');
				  $('.dm .active').find('ul').slideDown(300)
				}
				else
				  if ($(this).hasClass('active')) {
					  $(this).find('ul').slideUp(300)
					  $(this).removeClass('active');
				}
	})
/////////////////////////

$(".midle_tt .left .email input").hover(function(){
	$(".midle_tt .left .hide").stop(true,true).fadeIn(300)
	},function(){
		$(".midle_tt .left .hide").fadeOut(300)
		})		
/////////////////////////
$(".midle_tt .left #user_login input").click(function() {
    $(".midle_tt .left .hide_pass").slideDown(300)
});
$(".midle_tt .left #no_login input").click(function() {
    $(".midle_tt .left .hide_pass").slideUp(300)
});
////////////////////////////
$(".buoc3 .tab_detail p .hh").click(function() {
    $(".buoc3 .tab_detail .hide_hh").toggle(300)
});
///////////////////////////
$(window).load(function() {
var uynh_height=0;
$(".sp_style li").each(function() {
    var uynh_select=$(this).height();
	if(uynh_height<uynh_select){
		uynh_height=uynh_select;
		}
	else
	uynh_height=uynh_height;
});
$(".sp_style li").css("height",uynh_height+"px")
})
/////////////////////////
$('.dm li li').hover(function(){
	  $(this).children('ul:first').stop(true,true).slideDown(200)
	  },function(){
		  $(this).children('ul:first').slideUp(200)
		  });
//////////
	var uynh_w=$("#images img").width()
	var uynh_h=$("#images img").height()
  	var uynhheight=$("#uynhvip img").height();
	var uynhwidth=$("#uynhvip img").width();
	var uynhtop=(uynhheight-($("#images img").height()))/2
	var uynhleft=(uynhwidth-($("#images img").width()))/2
	$("#uynhvip img").css({"width":uynh_w+"px","height":uynh_h+"px"})
	$("#uynhvip img").toggle(function() {
        $(this).addClass("uynh_cursor").attr('title','Click vào để thu nhỏ hình').stop(true,true).animate({width:uynhwidth,height:uynhheight,top:-uynhtop,left:-uynhleft,opacity:1},200)
    },function(){
		$(this).removeClass("uynh_cursor").attr('title','Click vào để phóng to hình').stop(true,true).animate({width:uynh_w,height:uynh_h,top:0,left:0,opacity:0},200)
		});



		
});
// Ä‘iá»ƒm neo
$(function(){
	function scroll_to(div){
		$('html, body').animate({
			scrollTop: $(div).offset().top
		},1000);
	}
	$(window).load(function(){
		scroll_to(".truot");
		return true;
	});
});
 ///////////////////////////////////
$(function() {
        $(window).scroll(function() {
            if($(this).scrollTop() > 150) {
                $('.totop').fadeIn(500);	
            } else {
                $('.totop').fadeOut(500);
            }
        });
     
        $('.totop').click(function() {
            $('body,html').animate({scrollTop:0},800);
        });	
    });



	
// Ä‘iá»ƒm neo
$(function(){
	function scroll_to(div){
		$('html, body').animate({
			scrollTop: $(div).offset().top
		},1000);
	}
	
// Ä‘iá»ƒm neo
$(".list_hethong li").each(function() {
	$(this).click(function(){
		i=$(this).index()
		scroll_to("#lk"+i);
		return false;
	});
    
});
/////////////////
if($('body').height() < $(window).height()){
	  $(".midle_main").css({height: ($(window).height()-$("#footer").height())+"px"})
}

});
$(function() {
        $(window).scroll(function() {
            if($(this).scrollTop() >400) {
				$('.buy_cart').slideDown(1000);
            } else {
				$('.buy_cart').fadeOut(200);
            }
        });
    });
///////////////////////////////

///////////
function active_slide(selector){ 
	$(selector+' .img_slide_chitiet').not(":first").hide()
		$(selector).find("#slide_bottom li a").click(function(){
			var chuyen =$(this).attr("title")
			$(selector).find("#slide_bottom li a").removeClass("active")
			$(this).addClass("active")
			$(selector+" .img_slide_chitiet").hide()
			$(""+chuyen).show()
		});
}//silde//		

////////////////////
$(function() {

				$('#carouse4').carouFredSel({
					width:180,
					items:6,
					direction:"up",
					scroll: {
						items:1,
						pauseOnHover: true,
					},
					auto: {
						duration:2000,
						timeoutDuration:1000,
						easing: 'linear',
					},
					prev: '#prev1',
					next: '#next1',
				});
	
			});
$(function() {

				$('#carouse1').carouFredSel({
					width:783,
					items:4,
					direction:"left",
					scroll: {
						items:1,
						pauseOnHover: true,
					},
					auto: {
						duration:1200,
						timeoutDuration:2000,
						easing: 'linear',
					},
					prev: '#prev',
					next: '#next',
				});
	
			});
			
///////
$(function() {

				$('#carouse2').carouFredSel({
					width:964,
					items:6,
					direction:"left",
					scroll: {
						items:1,
						pauseOnHover: true,
					},
					auto: {
						duration:1200,
						timeoutDuration:2000,
						easing: 'linear',
					},
					prev: '#prev2',
					next: '#next2',
				});
	
			});

//		
///////
$(function() {

				$('#carouse5').carouFredSel({
					items:3,
					direction:"left",
					scroll: {
						items:1,
						pauseOnHover: true,
					},
					auto: {
						duration:1200,
						timeoutDuration:2000,
						easing: 'linear',
					},
					prev: '#prev5',
					next: '#next5',
				});
	
			});

//		
///////////////////
$(function(){
	$(".giovang_ct .top .right .hover").hover(function(){
		$(".giovang_ct .top .right .hide_hover").stop(true,true).animate({bottom:-90,opacity:1},300)
		},function(){
			$(".giovang_ct .top .right .hide_hover").stop(true,true).animate({bottom:-130,opacity:0},300)
			})
	})
//////////////////////////////
function str2num(val)
{
                val = '0' + val;
                val = parseInt(val);
                return val;
}
setInterval(function(){
    var future = new Date($(".nhapngay").html());
    var now = new Date();
    var difference = Math.floor((future.getTime() - now.getTime()) / 1000);
    
    var seconds = fixIntegers(difference % 60);
    difference = Math.floor(difference / 60);
    
    var minutes = fixIntegers(difference % 60);
    difference = Math.floor(difference / 60);
    
    var hours = fixIntegers(difference % 24);
    difference = Math.floor(difference / 24);
    
    var days = difference;
    
    $("#seconds").text(seconds + "s");
    $("#minutes").text(minutes + "m");
    $("#hours").text(hours + "h");
    $("#days").text(days + "d");
	
}, 1000);




   setInterval(function(){
	$(".giovang li").each(function() {
		var ngaynhap = new Date($(this).find(".nhapngay").html());
		var now = new Date();
		var difference = Math.floor((ngaynhap.getTime() - now.getTime()) / 1000);
		
		var seconds = fixIntegers(difference % 60);
		difference = Math.floor(difference / 60);
		
		var minutes = fixIntegers(difference % 60);
		difference = Math.floor(difference / 60);
		
		var hours = fixIntegers(difference % 24);
		difference = Math.floor(difference / 24);
		
		var days = difference;
		
		$(this).find(".seconds").text(seconds + "s");
		$(this).find(".minutes").text(minutes + "m");
		$(this).find(".hours").text(hours + "h");
		$(this).find(".days").text(days + "d");
	});
}, 1000);     

function fixIntegers(integer)
{
    if (integer < 0)
        integer = 0;
    if (integer < 10)
        return "0" + integer;
    return "" + integer;
}

//////////
$(function() {
    $('.slide_hot ul li:gt(0)').hide();
    setInterval(function(){
      $('.slide_hot ul li:first-child').fadeOut(1000)
         .next('li').fadeIn(1000)
         .end().appendTo('.slide_hot ul');},
      5000);
})
///////////////////

